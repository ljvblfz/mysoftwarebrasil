<?php
	define('STR_PM_ADDTOPRJ', "Zum Projekt hinzuf�?¼gen");
	define('STR_PM_CHOOSEPRJ', "W�?¤hle ein Projekt zu dem es hinzugef�?¼gt werden soll");
	define('STR_PM_ADDALLSEQ', "F�?¼ge alle Arbeitsg�?¤nge zu diesem AP\' hinzu");
?>