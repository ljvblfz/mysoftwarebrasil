<?php
	define('STR_SEV_SELECTONE', "Auswahl");
	define('STR_SEV_TABLETITLE', "Schweregraden - sortiert nach %s");
	define('STR_SEV_NOSEVS', "Es konnten keine Schweregraden gefunden werden!");
	define('STR_SEV_ID', "ID");
	define('STR_SEV_ACTIVEABB', "A");
	define('STR_SEV_ACTIVE', "Aktiv");
	define('STR_SEV_SHORT', "K�?¼rzel");
	define('STR_SEV_NAME', "Name");
	define('STR_SEV_WEIGHT', "Wichtung");
	define('STR_SEV_OPTIONS', "Optionen");
	define('STR_SEV_EDIT', "Bearbeite Schweregrad");
	define('STR_SEV_ADD', "Schweregrad hinzuf�?¼gen");
?>