<?php
	define('STR_PRIO_SELECTONE', "Auswahl");
	define('STR_PRIO_TABLETITLE', "Priorit�?¤ten - sortiert nach %s");
	define('STR_PRIO_NOPRIOS', "Es konnten keine Priorit�?¤ten gefunden werden!");
	define('STR_PRIO_ID', "ID");
	define('STR_PRIO_ACTIVEABB', "A");
	define('STR_PRIO_ACTIVE', "Aktiv");
	define('STR_PRIO_SHORT', "K�?¼rzel");
	define('STR_PRIO_NAME', "Name");
	define('STR_PRIO_WEIGHT', "Wichtung");
	define('STR_PRIO_OPTIONS', "Optionen");
	define('STR_PRIO_EDIT', "Bearbeite Priorit�?¤t");
	define('STR_PRIO_ADD', "Priorit�?¤t hinzuf�?¼gen");
	define('STR_PRIO_HIGHLIGHTEDNOTE', "** Unterlegte Felder m�?¼ssen gef�?¼llt werden!");
?>