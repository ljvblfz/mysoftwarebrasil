<?php
	define('STR_WTCH_TABLETITLE', "Meine Beobachtungsliste - %s");
	define('STR_WTCH_NOWTCHS', "Keine zu beobachtenden Eintr�?¤ge gefunden!");
	define('STR_WTCH_ID', "ID");
	define('STR_WTCH_TYPE', "Typ");
	define('STR_WTCH_SUMMARY', "Titel");
	define('STR_WTCH_WHO', "Wer");
	define('STR_WTCH_ACTIONS', "Aktionen");
	define('STR_WTCH_OPTIONS', "Optionen");
	define('STR_WTCH_EDIT', "Bearbeite %s Beobachtung");
	define('STR_WTCH_ADD', "Neue %s Beobachtung");
	define('STR_WTCH_YOUHAVENONE', "Sie haben keine Beobachtungen definiert.");
	define('STR_WTCH_HIGHLIGHTEDNOTE', "** Unterlegte Felder m�?¼ssen gef�?¼llt werden!");
	define('STR_WTCH_ALLSEQ', "Alle Arbeitsg�?¤nge");
	define('STR_WTCH_INVALIDITEM', "Ung�?¼ltiges Beobachtungsobjekt.");
	define('STR_WTCH_MYWTCH', "Meine Beobachtungsliste");
	define('STR_WTCH_PRODUCT', "Produkt");
	define('STR_WTCH_PROJECT', "Projekt");
	define('STR_WTCH_PRODUCTWO', "Product Arbeitsauftr�?¤ge");
	define('STR_WTCH_PRODUCTTICKET', "Produkt Ticket");
	define('STR_WTCH_WORKORDER', "Arbeitsauftr�?¤ge");
	define('STR_WTCH_TICKET', "Ticket");
	define('STR_WTCH_OPEN', "Offen");
	define('STR_WTCH_CLOSED', "Geschlossen");
	define('STR_WTCH_STATUS', "Status");
	define('STR_WTCH_ANYTHING', "Alles");
	define('STR_WTCH_ACCTWO', "Account Work Order");
	define('STR_WTCH_ACCTTCK', "Account Ticket");
?>