<?php
	define('STR_ATTR_OBJECTNOTPASSED', "Es wurde kein Objekt �?¼bergeben!");
	define('STR_ATTR_INVALIDTYPE', "Ein ung�?¼ltiger Typ wurde �?¼bergeben!");
	define('STR_ATTR_ATTRIBUTESET', "Attribut Zusammenstellung");
	define('STR_ATTR_ATTRIBUTESETS', "Attribut Zusammenstellungen");
	define('STR_ATTR_ACTIONS', "Aktionen");
	define('STR_ATTR_PRIORITIES', "Priotrit�?¤ten");
	define('STR_ATTR_SEVERITIES', "Schweregraden/Typ");
	define('STR_ATTR_STATUSES', "Stati");
	define('STR_ATTR_MAP', "Verbindung");
	define('STR_ATTR_ID', "ID");
	define('STR_ATTR_ACTIVE', "Aktiv");
	define('STR_ATTR_SHORT', "K�?¼rzel");
	define('STR_ATTR_NAME', "Name");
	define('STR_ATTR_ADDATTRIBUTESET', "Attribut Zusammenstellung hinzuf�?¼gen");
	define('STR_ATTR_EDITATTRIBUTESET', "Attribut Zusammenstellung bearbeiten");
	define('STR_ATTR_AVAILABLEVALUES', "Verf�?¼gbare Werte");
	define('STR_ATTR_USEDVALUES', "Benutze Werte");
	define('STR_ATTR_SELECTONE', "W�?¤hlen Sie");
	define('STR_ATTR_NEW', "Neu");
	define('STR_ATTR_TYPE', "Typ");
	define('STR_ATTR_NOATTRIBUTESETS', "Es wurden keine Attributzusammenstellungen definiert!");
	define('STR_ATTR_HIGHLIGHTEDNOTE', "** Unterlegte Felder sind m�?¼ssen gef�?¼llt werden!");
?>