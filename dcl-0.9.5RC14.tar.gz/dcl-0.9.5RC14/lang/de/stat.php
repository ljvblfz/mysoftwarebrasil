<?php
	define('STR_STAT_SELECTONE', "Auswahl");
	define('STR_STAT_TABLETITLE', "Status - Sortiert nach %s");
	define('STR_STAT_NOSTATS', "Es konnte keine Statusdefinition gefunden werden!");
	define('STR_STAT_ID', "ID");
	define('STR_STAT_ACTIVEABB', "A");
	define('STR_STAT_ACTIVE', "Aktiv");
	define('STR_STAT_SHORT', "K�?¼rzel");
	define('STR_STAT_NAME', "Name");
	define('STR_STAT_OPTIONS', "Optionen");
	define('STR_STAT_EDIT', "Bearbeite Status");
	define('STR_STAT_ADD', "Status hinzuf�?¼gen");
	define('STR_STAT_HIGHLIGHTEDNOTE', "** Unterlegte Felder m�?¼ssen ausgef�?¼llt werden");
	define('STR_STAT_TYPE', "Type");
?>