<?php
	define('STR_VER_TITLE', "Informatione �?¼ber System Version");
	define('STR_VER_DCL', "DCL Version");
	define('STR_VER_SERVEROS', "Server Betriebssystem");
	define('STR_VER_SERVERNAME', "Server Name");
	define('STR_VER_WEBSERVER', "Web Server");
	define('STR_VER_PHPVER', "PHP Version");
	define('STR_VER_YOURVER', "Ihre Versions Information");
	define('STR_VER_YOURIP', "Ihre IP Addresse");
	define('STR_VER_YOURBROWSER', "Ihr Browser");
?>