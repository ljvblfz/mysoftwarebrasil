<?php
	define('STR_TC_ACTIONTITLE', "Aktion (%s on %s) - %s");
	define('STR_TC_STATUS', "Status");
	define('STR_TC_VERSION', "Version");
	define('STR_TC_ACTION', "Aktion");
	define('STR_TC_HOURS', "Stunden");
	define('STR_TC_DESCRIPTION', "Beschreibung");
	define('STR_TC_EDIT', "Arbeitskarte bearbeiten");
	define('STR_TC_JCN', "AP#");
	define('STR_TC_SEQ', "AG");
	define('STR_TC_DETAILBELOW', "(Details siehe unten)");
	define('STR_TC_SUMMARY', "Zusammenfassung");
	define('STR_TC_DATE', "Datum");
	define('STR_TC_BY', "von");
	define('STR_TC_ETC', "Rest");
	define('STR_TC_BTNADD', "Neu");
	define('STR_TC_BTNMOD', "�?�??ndern");
	define('STR_TC_BTNCLR', "L�?¶schen");
	define('STR_TC_HIGHLIGHTEDNOTE', "** Unterlegte Felder m�?¼ssengef�?¼llt werden!");
	define('STR_TC_MODIFYNOTE', "Anmerkung: Wenn unten Arbeitskarten angezeigt werden, wird der Status and die Restzeit nicht ge�?¤ndert.");
	define('STR_TC_MODIFY', "�?�??ndern");
	define('STR_TC_DELETE', "L�?¶schen");
	define('STR_TC_BATCHUPDATE', "Batch Aktualisierung");
?>