<?php
	define('STR_ACCT_SELECTONE', "Auswahl.");
	define('STR_ACCT_DIRBYNAME', "Kundenverzeichnis nach Namen");
	define('STR_ACCT_TABLETITLE', "Kunden - sortiert nach %s mit %s");
	define('STR_ACCT_NOTFOUND', "Keine Kunden %s mit %s gefunden");
	define('STR_ACCT_OPTIONS', "Optionen");
	define('STR_ACCT_ID', "ID");
	define('STR_ACCT_ACTIVEABB', "Akt.");
	define('STR_ACCT_ACTIVE', "Aktiv");
	define('STR_ACCT_NAME', "Name");
	define('STR_ACCT_NOTES', "Anmerkungen");
	define('STR_ACCT_SHORT', "K�?¼rzel");
	define('STR_ACCT_CITY', "Stadt");
	define('STR_ACCT_STATEABB', "Str");
	define('STR_ACCT_STATE', "Land");
	define('STR_ACCT_ZIP', "PLZ");
	define('STR_ACCT_CONTACT', "Kontakt");
	define('STR_ACCT_CONTACTPH', "Kontakt Tel");
	define('STR_ACCT_FAX', "Fax");
	define('STR_ACCT_EDITACCOUNT', "Bearbeite Kunde");
	define('STR_ACCT_ADDNEWACCOUNT', "Neuer Kunde");
	define('STR_ACCT_HIGHLIGHTEDNOTE', "** Unterlegte Felder m�?¼ssen gef�?¼llt werden!");
	define('STR_ACCT_NOOBJECTERR', "Es wurde kein Kundenobjekt an ShowDetail �?¼bergeben!");
	define('STR_ACCT_ACCOUNTSEARCH', "Suche nach Kunden");
	define('STR_ACCT_SEARCHTEXT', "Textsuche");
	define('STR_ACCT_WATCHWO', "Watch WO");
	define('STR_ACCT_WATCHTCK', "Watch Ticket");
?>