<?php
	define('STR_VW_SAVESEARCH', "Suche speichern");
	define('STR_VW_EXPORTRESULTS', "Ergebnisse exportieren");
	define('STR_VW_BATCHTIMECARD', "Batch Timecard");
	define('STR_VW_VIEWOBJECTNOTPASSED', "Es wurde keine Ansicht �?¼bergeben!");
	define('STR_VW_UNKNOWNTABLE', "Unbekannte Tabelle %s");
	define('STR_VW_QUERYERR', "Fehler bei Abfrage: %s");
	define('STR_VW_NOMATCHES', "Es wurden keine Treffer gefunden");
	define('STR_VW_OPEN', "Offen: %d");
	define('STR_VW_CLOSED', "Geschlossen: %d");
	define('STR_VW_TOTAL', "Zusammenfassung: %d");
	define('STR_VW_ID', "ID");
	define('STR_VW_OWNER', "Besitzer");
	define('STR_VW_PUBLIC', "�?�??ffendlich");
	define('STR_VW_NAME', "Name");
	define('STR_VW_TABLE', "Tabelle");
	define('STR_VW_ADDVIEW', "Ansicht hinzuf�?¼gen");
	define('STR_VW_NOVIEWS', "Es wurden keine �?¶ffendlichen oder privaten Ansichten gefunden!");
	define('STR_VW_TITLE', "Ansichten sortiert nach %s");
	define('STR_VW_SETUP', "Setup");
?>