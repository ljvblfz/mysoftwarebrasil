<?php
	define('STR_ACTN_SELECTONE', "Auswahl");
	define('STR_ACTN_TABLETITLE', "Aktionen - sortiert nach %s");
	define('STR_ACTN_NOACTIONS', "Es wurden keine Aktionen gefunden !");
	define('STR_ACTN_ID', "ID");
	define('STR_ACTN_ACTIVEABB', "A");
	define('STR_ACTN_ACTIVE', "Aktiv");
	define('STR_ACTN_SHORT', "K�?¼rzel");
	define('STR_ACTN_NAME', "Name");
	define('STR_ACTN_OPTIONS', "Optionen");
	define('STR_ACTN_EDIT', "Bearbeite Aktion");
	define('STR_ACTN_ADD', "Aktion hinzuf�?¼gen");
	define('STR_ACTN_HIGHLIGHTEDNOTE', "** Unterlegte Felder m�?¼ssen gef�?¼llt werden!");
	define('STR_ACTN_ATTRIBUTENOTE', "Dieser Eintrag muss mit einer Attributzusammenstellung verbunden werden. Siehe Men�?¼ Admin..Attribute");
?>