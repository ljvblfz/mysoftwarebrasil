<?php
	define('STR_DEPT_SELECTONE', "Auswahl");
	define('STR_DEPT_TABLETITLE', "Abteilungen - sortiert nach %s");
	define('STR_DEPT_NODEPTS', "Es wurden keine Abteilungen gefunden!");
	define('STR_DEPT_ID', "ID");
	define('STR_DEPT_ACTIVEABB', "A");
	define('STR_DEPT_ACTIVE', "Aktiv");
	define('STR_DEPT_SHORT', "K�?¼rzel");
	define('STR_DEPT_NAME', "Name");
	define('STR_DEPT_OPTIONS', "Optionen");
	define('STR_DEPT_EDIT', "Abteilung bearbeiten");
	define('STR_DEPT_ADD', "Abteilung hinzuf�?¼gen");
	define('STR_DEPT_HIGHLIGHTEDNOTE', "** Unterlegte Felder m�?¼ssen gef�?¼llt werden!");
?>