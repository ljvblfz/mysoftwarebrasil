<?php
	define('STR_STAT_SELECTONE', "Izberi");
	define('STR_STAT_TABLETITLE', "Statusi - razvr�?¹�?¨eni po %s");
	define('STR_STAT_NOSTATS', "Ne najdem statusa za prikaz!");
	define('STR_STAT_ID', "ID");
	define('STR_STAT_ACTIVEABB', "A");
	define('STR_STAT_ACTIVE', "Aktiven");
	define('STR_STAT_SHORT', "Kratko");
	define('STR_STAT_NAME', "Ime");
	define('STR_STAT_OPTIONS', "Mo�?¾nosti");
	define('STR_STAT_EDIT', "Popravi status");
	define('STR_STAT_ADD', "Dodaj status");
	define('STR_STAT_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna!");
	define('STR_STAT_TYPE', "Type");
?>