<?php
	define('STR_ACTN_SELECTONE', "Izberi");
	define('STR_ACTN_TABLETITLE', "Akcije - razvr�?¹�?¨ene po %s");
	define('STR_ACTN_NOACTIONS', "Ni najti akcij za prikaz!  Morda �?¹e nima�?¹ definiranih akcije na sistemu!");
	define('STR_ACTN_ID', "ID");
	define('STR_ACTN_ACTIVEABB', "A");
	define('STR_ACTN_ACTIVE', "Aktiven");
	define('STR_ACTN_SHORT', "Kratko");
	define('STR_ACTN_NAME', "Ime");
	define('STR_ACTN_OPTIONS', "Mo�?¾nosti");
	define('STR_ACTN_EDIT', "Popravi akcijo");
	define('STR_ACTN_ADD', "Dodaj akcijo");
	define('STR_ACTN_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna!");
	define('STR_ACTN_ATTRIBUTENOTE', "This item will need to be associated with an attribute set to be used.  See Admin..Attributes menu item.");
?>