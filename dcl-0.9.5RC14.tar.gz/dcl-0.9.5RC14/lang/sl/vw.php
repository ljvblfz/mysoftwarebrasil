<?php
	define('STR_VW_SAVESEARCH', "Shrani Pogled");
	define('STR_VW_EXPORTRESULTS', "Izvozi Rezultat");
	define('STR_VW_BATCHTIMECARD', "Batch Timecard");
	define('STR_VW_VIEWOBJECTNOTPASSED', "A view object was not passed!");
	define('STR_VW_UNKNOWNTABLE', "Unknown Table %s");
	define('STR_VW_QUERYERR', "Error executing query: %s");
	define('STR_VW_NOMATCHES', "No Matches Found");
	define('STR_VW_OPEN', "Odprt: %d");
	define('STR_VW_CLOSED', "Zaprt: %d");
	define('STR_VW_TOTAL', "Skupaj: %d");
	define('STR_VW_ID', "ID");
	define('STR_VW_OWNER', "Odprl");
	define('STR_VW_PUBLIC', "Javni");
	define('STR_VW_NAME', "Ime");
	define('STR_VW_TABLE', "Tabela");
	define('STR_VW_ADDVIEW', "Dodaj Pogled");
	define('STR_VW_NOVIEWS', "No Public Or Private Views Found!");
	define('STR_VW_TITLE', "Pogledi razvr�?¹�?¨eni po %s");
	define('STR_VW_SETUP', "Setup");
?>