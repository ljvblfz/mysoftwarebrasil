<?php
	define('STR_ACCT_SELECTONE', "Izberi");
	define('STR_ACCT_DIRBYNAME', "Imenik strank po imenu");
	define('STR_ACCT_TABLETITLE', "Stranke - Razporejeni po %s ki vsebuje %s");
	define('STR_ACCT_NOTFOUND', "Ne najdem stranke za %s, ki vsebuje %s");
	define('STR_ACCT_OPTIONS', "Mo�?¾nosti");
	define('STR_ACCT_ID', "ID");
	define('STR_ACCT_ACTIVEABB', "A");
	define('STR_ACCT_ACTIVE', "Aktivna");
	define('STR_ACCT_NAME', "Ime");
	define('STR_ACCT_NOTES', "Bele�?¾ke");
	define('STR_ACCT_SHORT', "Kratko");
	define('STR_ACCT_CITY', "Kraj");
	define('STR_ACCT_STATEABB', "St");
	define('STR_ACCT_STATE', "Dr�?¾ava");
	define('STR_ACCT_ZIP', "Po�?¹tna �?¹tevilka");
	define('STR_ACCT_CONTACT', "Kontakt");
	define('STR_ACCT_CONTACTPH', "Tel.�?¹t. kontakta");
	define('STR_ACCT_FAX', "Fax");
	define('STR_ACCT_EDITACCOUNT', "Spremeni stranko");
	define('STR_ACCT_ADDNEWACCOUNT', "Dodaj novo stranko");
	define('STR_ACCT_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna !");
	define('STR_ACCT_NOOBJECTERR', "Strankin objekt ni bil poslan v ShowDetail!");
	define('STR_ACCT_ACCOUNTSEARCH', "Iskanje strank");
	define('STR_ACCT_SEARCHTEXT', "Iskalni niz");
	define('STR_ACCT_WATCHWO', "Watch WO");
	define('STR_ACCT_WATCHTCK', "Watch Ticket");
?>