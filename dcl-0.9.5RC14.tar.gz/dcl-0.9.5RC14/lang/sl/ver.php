<?php
	define('STR_VER_TITLE', "Informacije o verziji sistema");
	define('STR_VER_DCL', "DCL Verzija ");
	define('STR_VER_SERVEROS', "Streznikov tip OS-a");
	define('STR_VER_SERVERNAME', "Ime streznika");
	define('STR_VER_WEBSERVER', "Web streznik");
	define('STR_VER_PHPVER', "PHP Verzija");
	define('STR_VER_YOURVER', "Informacije o tvojem sistemu");
	define('STR_VER_YOURIP', "Tvoj IP naslov");
	define('STR_VER_YOURBROWSER', "Tvoj brskalnik");
?>