<?php
	define('STR_PRIO_SELECTONE', "Izberi");
	define('STR_PRIO_TABLETITLE', "Prioritete - razvr�?¹�?¨ene po %s");
	define('STR_PRIO_NOPRIOS', "Ne najdem prioritet za prikaz!");
	define('STR_PRIO_ID', "ID");
	define('STR_PRIO_ACTIVEABB', "A");
	define('STR_PRIO_ACTIVE', "Aktiven");
	define('STR_PRIO_SHORT', "Kratko");
	define('STR_PRIO_NAME', "Ime");
	define('STR_PRIO_WEIGHT', "Obte�?¾itev");
	define('STR_PRIO_OPTIONS', "Mo�?¾nosti");
	define('STR_PRIO_EDIT', "Popravi prioriteto");
	define('STR_PRIO_ADD', "Dodaj prioriteto");
	define('STR_PRIO_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna!");
?>