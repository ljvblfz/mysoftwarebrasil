<?php
	define('STR_DEPT_SELECTONE', "Izberi");
	define('STR_DEPT_TABLETITLE', "Oddelki - razvr�?¹�?¨eni po %s");
	define('STR_DEPT_NODEPTS', "Nisem na�?¹el oddelkov za prikaz.");
	define('STR_DEPT_ID', "ID");
	define('STR_DEPT_ACTIVEABB', "A");
	define('STR_DEPT_ACTIVE', "Aktiven");
	define('STR_DEPT_SHORT', "Kratko");
	define('STR_DEPT_NAME', "Ime");
	define('STR_DEPT_OPTIONS', "Mo�?¾nosti");
	define('STR_DEPT_EDIT', "Popravi oddelek");
	define('STR_DEPT_ADD', "Dodaj oddelek");
	define('STR_DEPT_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna!");
?>