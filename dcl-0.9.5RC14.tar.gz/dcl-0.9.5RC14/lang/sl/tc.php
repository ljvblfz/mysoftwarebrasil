<?php
	define('STR_TC_ACTIONTITLE', "Akcija (%s on %s) - %s");
	define('STR_TC_STATUS', "Status");
	define('STR_TC_VERSION', "Verzija");
	define('STR_TC_ACTION', "Akcija");
	define('STR_TC_HOURS', "Ur");
	define('STR_TC_DESCRIPTION', "Opis");
	define('STR_TC_EDIT', "Popraveg �?¨asovne kartice");
	define('STR_TC_JCN', "ND#");
	define('STR_TC_SEQ', "Sek");
	define('STR_TC_DETAILBELOW', "(Podrobnosti spodaj)");
	define('STR_TC_SUMMARY', "Povzetek");
	define('STR_TC_DATE', "Datum");
	define('STR_TC_BY', "Od");
	define('STR_TC_ETC', "�?©e_ur");
	define('STR_TC_BTNADD', "Dodaj");
	define('STR_TC_BTNMOD', "Spremeni");
	define('STR_TC_BTNCLR', "O�?¨isti");
	define('STR_TC_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna!");
	define('STR_TC_MODIFYNOTE', "OPOMBA: �?�?a se pojavi �?¨asovna kartica pod to, status in \\\"�?¹e ur\\\" ne bo spremenjen.");
	define('STR_TC_MODIFY', "Spremeni");
	define('STR_TC_DELETE', "Zbri�?¹i");
	define('STR_TC_BATCHUPDATE', "Skupinski popravek");
?>