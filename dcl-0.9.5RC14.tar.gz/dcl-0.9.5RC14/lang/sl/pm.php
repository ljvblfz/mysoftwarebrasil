<?php
	define('STR_PM_ADDTOPRJ', "Dodaj v projekt");
	define('STR_PM_CHOOSEPRJ', "Izberi projekt, v katerega naj dodam");
	define('STR_PM_ADDALLSEQ', "Dodaj vse sekvence za ta DN#");
?>