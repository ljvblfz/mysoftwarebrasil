<?php
	define('STR_CHK_INITIATE', "Za�?¨ni");
	define('STR_CHK_TEMPLATE', "Predloga");
	define('STR_CHK_TEMPLATES', "Predloge");
	define('STR_CHK_NEWTEMPLATE', "Nova Predloga");
	define('STR_CHK_CHECKLISTTEMPLATES', "Checklist Predloge");
	define('STR_CHK_CHECKLISTTEMPLATE', "Checklist Predloga");
	define('STR_CHK_CHECKLISTNAME', "Checklist Ima");
	define('STR_CHK_INITIATEDCHECKLISTS', "Za�?¨ete Checkliste");
	define('STR_CHK_INITIATECHECKLIST', "Za�?¨ni Checklisto");
	define('STR_CHK_SUMMARY', "Povzetek");
	define('STR_CHK_STATUS', "Status");
	define('STR_CHK_ERRLOADINGTPLID', "Napaka pri nalaganju predloge ID #%d");
	define('STR_CHK_TEMPLATEISINACTIVE', "Predloga je neaktivna in je ne morem za�?¨eti.");
	define('STR_CHK_COULDNOTCOPYTPL', "Ne morem kopirati preldoge v novo checklisto.  Prekinjam operacijo.");
	define('STR_CHK_ERRORDATABASEENTRY', "Napaka pri izdelavi baze za checkliste.");
	define('STR_CHK_STATE', "Status");
?>