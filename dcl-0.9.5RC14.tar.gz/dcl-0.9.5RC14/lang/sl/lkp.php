<?php
	define('STR_LKP_ADDTITLE', "Dodaj poizvedovanje");
	define('STR_LKP_EDITTITLE', "Popravi poizvedovanje");
	define('STR_LKP_TABLETITLE', "Poizvedovanja");
	define('STR_LKP_NOLOOKUPS', "Ne najdem poizvedovanj!");
	define('STR_LKP_ID', "ID");
	define('STR_LKP_ACTIVEABB', "A");
	define('STR_LKP_ACTIVE', "Aktvino");
	define('STR_LKP_NAME', "Ime");
	define('STR_LKP_OPTIONS', "Mo�?¾noasti");
	define('STR_LKP_NOITEMS', "Ni objektov za to poizvedovanje!");
	define('STR_LKP_NOTFOUND', "Poizvedovanje ID %d ne obstaja!");
?>