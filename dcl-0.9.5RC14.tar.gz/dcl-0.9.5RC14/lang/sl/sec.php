<?php
	define('STR_SEC_SECLOG', "Security Logs");
	define('STR_SEC_SECLOGTITLE', "Security Logs Between %s and %s for %s");
	define('STR_SEC_GENERATEREPORTFOR', "Generiraj poro�?¨ilo za");
	define('STR_SEC_DATERANGE', "Date Range");
	define('STR_SEC_BEGIN', "Za�?¨eto");
	define('STR_SEC_ENDING', "Kon�?¨ano");
	define('STR_SEC_DATEERR', "Ne morem natisniti poro�?¨ila brez za�?¨etnega in kon�?¨nega datuma.");
	define('STR_SEC_ACTIONON', "Action On");
	define('STR_SEC_ACTIONTXT', "Action");
	define('STR_SEC_ACTIONPARAM', "Details");
	define('STR_SEC_ALLUSERS', "All Users");
	define('STR_SEC_RPTERROR', "An error occured while rendering the report.");
	define('STR_SEC_RPTNODATA', "No data returned.  Please try a broader query.");
?>