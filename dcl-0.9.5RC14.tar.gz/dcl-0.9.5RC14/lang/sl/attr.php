<?php
	define('STR_ATTR_OBJECTNOTPASSED', "An object was not passed!");
	define('STR_ATTR_INVALIDTYPE', "An invalid type was passed!");
	define('STR_ATTR_ATTRIBUTESET', "Zbirka atributov");
	define('STR_ATTR_ATTRIBUTESETS', "Zbirke atributov");
	define('STR_ATTR_ACTIONS', "Akcije");
	define('STR_ATTR_PRIORITIES', "Prioritete");
	define('STR_ATTR_SEVERITIES', "Pomembnosti/Tipi");
	define('STR_ATTR_STATUSES', "Statusi");
	define('STR_ATTR_MAP', "Map");
	define('STR_ATTR_ID', "ID");
	define('STR_ATTR_ACTIVE', "Aktiven");
	define('STR_ATTR_SHORT', "Kratko");
	define('STR_ATTR_NAME', "Ime");
	define('STR_ATTR_ADDATTRIBUTESET', "Dodaj zbirko atributov");
	define('STR_ATTR_EDITATTRIBUTESET', "Popravi zbirko atributov");
	define('STR_ATTR_AVAILABLEVALUES', "Poznaner vrednosti");
	define('STR_ATTR_USEDVALUES', "Uporabljene Vrednosti");
	define('STR_ATTR_SELECTONE', "Izberi");
	define('STR_ATTR_NEW', "Nov");
	define('STR_ATTR_TYPE', "Tip");
	define('STR_ATTR_NOATTRIBUTESETS', "Ni definiranih sbirk atributov!");
	define('STR_ATTR_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna!");
?>