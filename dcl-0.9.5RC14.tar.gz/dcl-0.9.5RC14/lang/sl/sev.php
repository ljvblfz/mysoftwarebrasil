<?php
	define('STR_SEV_SELECTONE', "Izberi");
	define('STR_SEV_TABLETITLE', "Severities - razvr�?¹�?¨ene po %s");
	define('STR_SEV_NOSEVS', "Ne najdem Severities za prikaz!");
	define('STR_SEV_ID', "ID");
	define('STR_SEV_ACTIVEABB', "A");
	define('STR_SEV_ACTIVE', "Aktivna");
	define('STR_SEV_SHORT', "Kratko");
	define('STR_SEV_NAME', "Ime");
	define('STR_SEV_WEIGHT', "Obte�?¾itev");
	define('STR_SEV_OPTIONS', "Mo�?¾nosti");
	define('STR_SEV_EDIT', "Popravi Severity");
	define('STR_SEV_ADD', "Dodaj Severity");
?>