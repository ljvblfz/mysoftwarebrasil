<?php
	define('STR_WTCH_TABLETITLE', "Moji opomniki - %s");
	define('STR_WTCH_NOWTCHS', "Ne najdem opomnikov za prikaz!");
	define('STR_WTCH_ID', "ID");
	define('STR_WTCH_TYPE', "Tip");
	define('STR_WTCH_SUMMARY', "Povzetek");
	define('STR_WTCH_WHO', "Kdo");
	define('STR_WTCH_ACTIONS', "Akcije");
	define('STR_WTCH_OPTIONS', "Mo�?¾nosti");
	define('STR_WTCH_EDIT', "Spremeni %s opozorilnik");
	define('STR_WTCH_ADD', "Dodaj %s opozorilnik");
	define('STR_WTCH_YOUHAVENONE', "Nima�?¹ opozorilnikov.");
	define('STR_WTCH_HIGHLIGHTEDNOTE', "** Osvetljena polja so obvezna!");
	define('STR_WTCH_ALLSEQ', "Vse sekvence");
	define('STR_WTCH_INVALIDITEM', "Eh? Invalid watch item.");
	define('STR_WTCH_MYWTCH', "Moji opozorilniki");
	define('STR_WTCH_PRODUCT', "Izdelek");
	define('STR_WTCH_PROJECT', "Projekt");
	define('STR_WTCH_PRODUCTWO', "Produkt DN");
	define('STR_WTCH_PRODUCTTICKET', "Produkt Ticket");
	define('STR_WTCH_WORKORDER', "Delovni nalog");
	define('STR_WTCH_TICKET', "Ticket");
	define('STR_WTCH_OPEN', "Odprto");
	define('STR_WTCH_CLOSED', "Zaprto");
	define('STR_WTCH_STATUS', "Status");
	define('STR_WTCH_ANYTHING', "Karkoli");
	define('STR_WTCH_ACCTWO', "Account Work Order");
	define('STR_WTCH_ACCTTCK', "Account Ticket");
?>