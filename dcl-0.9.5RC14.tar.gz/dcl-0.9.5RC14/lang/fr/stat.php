<?php
	define('STR_STAT_SELECTONE', "A S�?©lectionner");
	define('STR_STAT_TABLETITLE', "Statuts - Tri�?©s Par %s");
	define('STR_STAT_NOSTATS', "Pas de statuts trouv�?©s �?  afficher. Vous n\'avez peut-�?ªtre pas encore de statuts d�?©finis dans votre syst�?¨me!");
	define('STR_STAT_ID', "ID");
	define('STR_STAT_ACTIVEABB', "A");
	define('STR_STAT_ACTIVE', "Actif");
	define('STR_STAT_SHORT', "Nom court");
	define('STR_STAT_NAME', "Nom");
	define('STR_STAT_OPTIONS', "Options");
	define('STR_STAT_EDIT', "Editer Statut");
	define('STR_STAT_ADD', "Ajouter Statut");
	define('STR_STAT_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoires!");
	define('STR_STAT_TYPE', "Type");
?>