<?php
	define('STR_ACCT_SELECTONE', "A s�?©lectionner.");
	define('STR_ACCT_DIRBYNAME', "R�?©pertoire Clients Par Nom");
	define('STR_ACCT_TABLETITLE', "Clients - Tries Par %s Commen�?§ant par %s");
	define('STR_ACCT_NOTFOUND', "Pas De Clients Trouv�?©s Pour %s Commen�?§ant par %s");
	define('STR_ACCT_OPTIONS', "Options");
	define('STR_ACCT_ID', "ID");
	define('STR_ACCT_ACTIVEABB', "A");
	define('STR_ACCT_ACTIVE', "Actif");
	define('STR_ACCT_NAME', "Nom");
	define('STR_ACCT_NOTES', "Notes");
	define('STR_ACCT_SHORT', "Code client");
	define('STR_ACCT_CITY', "Ville");
	define('STR_ACCT_STATEABB', "Dep");
	define('STR_ACCT_STATE', "Etat");
	define('STR_ACCT_ZIP', "Code Postal");
	define('STR_ACCT_CONTACT', "Contact");
	define('STR_ACCT_CONTACTPH', "Tel Contact");
	define('STR_ACCT_FAX', "Fax");
	define('STR_ACCT_EDITACCOUNT', "Editer Client");
	define('STR_ACCT_ADDNEWACCOUNT', "Ajouter Client");
	define('STR_ACCT_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoires!");
	define('STR_ACCT_NOOBJECTERR', "L\'objet client pas pass�?© par ShowDetail!");
	define('STR_ACCT_ACCOUNTSEARCH', "Recherche Client");
	define('STR_ACCT_SEARCHTEXT', "Rechercher Texte");
	define('STR_ACCT_WATCHWO', "Watch WO");
	define('STR_ACCT_WATCHTCK', "Watch Ticket");
?>