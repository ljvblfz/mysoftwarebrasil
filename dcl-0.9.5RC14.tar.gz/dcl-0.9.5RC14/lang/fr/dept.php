<?php
	define('STR_DEPT_SELECTONE', "A Selectionner");
	define('STR_DEPT_TABLETITLE', "D�?©partements - Tri�?©s Par %s");
	define('STR_DEPT_NODEPTS', "Pas de d�?©partements trouv�?©s �?  afficher!  Vous n\'avez peut-�?ªtre pas encore de d�?©partements dans votre syst�?¨me!");
	define('STR_DEPT_ID', "ID");
	define('STR_DEPT_ACTIVEABB', "A");
	define('STR_DEPT_ACTIVE', "Actif");
	define('STR_DEPT_SHORT', "Code");
	define('STR_DEPT_NAME', "Nom");
	define('STR_DEPT_OPTIONS', "Options");
	define('STR_DEPT_EDIT', "Editer D�?©partement");
	define('STR_DEPT_ADD', "Ajouter D�?©partement");
	define('STR_DEPT_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoires!");
?>