<?php
	define('STR_PRIO_SELECTONE', "A S�?©lectionner");
	define('STR_PRIO_TABLETITLE', "Priorit�?©s - Tri�?©es par %s");
	define('STR_PRIO_NOPRIOS', "Pas de priorit�?©s trouv�?©es �?  afficher!  Vous n\'avez peut-�?ªtre pas encore de priorit�?©es d�?©finies dans votre syst�?¨me!");
	define('STR_PRIO_ID', "ID");
	define('STR_PRIO_ACTIVEABB', "A");
	define('STR_PRIO_ACTIVE', "Active");
	define('STR_PRIO_SHORT', "Code");
	define('STR_PRIO_NAME', "Nom");
	define('STR_PRIO_WEIGHT', "Poids");
	define('STR_PRIO_OPTIONS', "Options");
	define('STR_PRIO_EDIT', "Editer Priorit�?©");
	define('STR_PRIO_ADD', "Ajouter Priorit�?©");
	define('STR_PRIO_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoires!");
?>