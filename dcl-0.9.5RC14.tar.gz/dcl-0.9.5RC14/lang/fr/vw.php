<?php
	define('STR_VW_SAVESEARCH', "Sauver Recherche");
	define('STR_VW_EXPORTRESULTS', "Exporter Resultats");
	define('STR_VW_BATCHTIMECARD', "Fiche de Temps Batch");
	define('STR_VW_VIEWOBJECTNOTPASSED', "Un objet vue n\'a pas �?©t�?© pass�?©!");
	define('STR_VW_UNKNOWNTABLE', "Table inconnue %s");
	define('STR_VW_QUERYERR', "Erreur d\'ex�?©cution de la requ�?ªte: %s");
	define('STR_VW_NOMATCHES', "Pas d\'occurences trouv�?©es");
	define('STR_VW_OPEN', "Ouvert: %d");
	define('STR_VW_CLOSED', "Ferm�?©: %d");
	define('STR_VW_TOTAL', "Total: %d");
	define('STR_VW_ID', "ID");
	define('STR_VW_OWNER', "Propri�?©taire");
	define('STR_VW_PUBLIC', "Public");
	define('STR_VW_NAME', "Nom");
	define('STR_VW_TABLE', "Table");
	define('STR_VW_ADDVIEW', "Ajouter Vue");
	define('STR_VW_NOVIEWS', "Pas de vues Publiques ou Priv�?©e trouv�?©es!");
	define('STR_VW_TITLE', "Vues Tri�?©es Par %s");
	define('STR_VW_SETUP', "Setup");
?>