<?php
	define('STR_ATTR_OBJECTNOTPASSED', "Un objet n\'est pas pass�?© !");
	define('STR_ATTR_INVALIDTYPE', "Un type invalide a �?©t�?© pass�?© !");
	define('STR_ATTR_ATTRIBUTESET', "Ensemble d\'Attributs");
	define('STR_ATTR_ATTRIBUTESETS', "Ensembles d\'Attributs");
	define('STR_ATTR_ACTIONS', "Actions");
	define('STR_ATTR_PRIORITIES', "Priorit�?©s");
	define('STR_ATTR_SEVERITIES', "S�?©v�?©rit�?©s/Types");
	define('STR_ATTR_STATUSES', "Statuts");
	define('STR_ATTR_MAP', "Map");
	define('STR_ATTR_ID', "ID");
	define('STR_ATTR_ACTIVE', "Actif");
	define('STR_ATTR_SHORT', "Court");
	define('STR_ATTR_NAME', "Nom");
	define('STR_ATTR_ADDATTRIBUTESET', "Ajouter un Ensemble d\'Attributs");
	define('STR_ATTR_EDITATTRIBUTESET', "Editer une Ensemble d\'Attributs");
	define('STR_ATTR_AVAILABLEVALUES', "Valeurs Disponibles");
	define('STR_ATTR_USEDVALUES', "Valeurs Utilis�?©es");
	define('STR_ATTR_SELECTONE', "Selectionner en une");
	define('STR_ATTR_NEW', "Nouveau");
	define('STR_ATTR_TYPE', "Type");
	define('STR_ATTR_NOATTRIBUTESETS', "Aucun Ensemble d\'Attributs n\'est d�?©fini !");
	define('STR_ATTR_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoire !");
?>