<?php
	define('STR_PM_ADDTOPRJ', "Ajouter Au Projet");
	define('STR_PM_CHOOSEPRJ', "Choisir le projet auquel l\'ajouter");
	define('STR_PM_ADDALLSEQ', "Ajouter Toutes les S�?©quences pour ce No d\'Ordre de Travail");
?>