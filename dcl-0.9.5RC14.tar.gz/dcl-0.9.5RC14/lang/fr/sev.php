<?php
	define('STR_SEV_SELECTONE', "A S�?©lectionner");
	define('STR_SEV_TABLETITLE', "S�?©v�?©rit�?©s - Tri�?©es Par %s");
	define('STR_SEV_NOSEVS', "Pas de s�?©v�?©rit�?©s trouver �?  afficher. Vous n\'avez peut-�?ªtre pas encore de s�?©v�?©rit�?©s d�?©finies dans votre syst�?¨me!");
	define('STR_SEV_ID', "ID");
	define('STR_SEV_ACTIVEABB', "A");
	define('STR_SEV_ACTIVE', "Active");
	define('STR_SEV_SHORT', "Nom court");
	define('STR_SEV_NAME', "Nom");
	define('STR_SEV_WEIGHT', "Poids");
	define('STR_SEV_OPTIONS', "Options");
	define('STR_SEV_EDIT', "Editer S�?©v�?©rit�?©");
	define('STR_SEV_ADD', "Ajouter S�?©v�?©rit�?©");
?>