<?php
	define('STR_TC_ACTIONTITLE', "Action (%s le %s) - %s");
	define('STR_TC_STATUS', "Statut");
	define('STR_TC_VERSION', "Version");
	define('STR_TC_ACTION', "Action");
	define('STR_TC_HOURS', "Heures");
	define('STR_TC_DESCRIPTION', "Description");
	define('STR_TC_EDIT', "Editer Fiche d\'Appel");
	define('STR_TC_JCN', "No Appel");
	define('STR_TC_SEQ', "Seq");
	define('STR_TC_DETAILBELOW', "(Detail Ci-dessous)");
	define('STR_TC_SUMMARY', "R�?©sum�?©");
	define('STR_TC_DATE', "Date");
	define('STR_TC_BY', "Par");
	define('STR_TC_ETC', "RAF");
	define('STR_TC_BTNADD', "Ajouter");
	define('STR_TC_BTNMOD', "Modifier");
	define('STR_TC_BTNCLR', "Rafra�?®chir");
	define('STR_TC_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoires!");
	define('STR_TC_MODIFYNOTE', "NOTE: Si une fiche d\'appel apparait sous celle-ci, le statut et les heures restantes ne seront pas chang�?©s.");
	define('STR_TC_MODIFY', "Modifier");
	define('STR_TC_DELETE', "Effacer");
	define('STR_TC_BATCHUPDATE', "Mise �?  jour Batch");
?>