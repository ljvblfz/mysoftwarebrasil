<?php
	define('STR_VER_TITLE', "Information de version du syst�?¨me");
	define('STR_VER_DCL', "Version de DCL");
	define('STR_VER_SERVEROS', "OS-Type du Serveur");
	define('STR_VER_SERVERNAME', "Nom du Serveur");
	define('STR_VER_WEBSERVER', "Serveur Web");
	define('STR_VER_PHPVER', "Version PHP");
	define('STR_VER_YOURVER', "Votre Information de Version");
	define('STR_VER_YOURIP', "Votre Adresse IP");
	define('STR_VER_YOURBROWSER', "Votre Navigateur");
?>