<?php
	define('STR_ACTN_SELECTONE', "A s�?©lectionner");
	define('STR_ACTN_TABLETITLE', "Actions - Tri�?©es par %s");
	define('STR_ACTN_NOACTIONS', "Pas d\'actions trouv�?©es �?  afficher !  Vous n\'avez peut-�?ªtre pas encore d\'actions d�?©finies dans le syst�?¨me!");
	define('STR_ACTN_ID', "ID");
	define('STR_ACTN_ACTIVEABB', "A");
	define('STR_ACTN_ACTIVE', "Actif");
	define('STR_ACTN_SHORT', "Nom court");
	define('STR_ACTN_NAME', "Nom");
	define('STR_ACTN_OPTIONS', "Options");
	define('STR_ACTN_EDIT', "Editer Action");
	define('STR_ACTN_ADD', "Ajouter Action");
	define('STR_ACTN_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoires!");
	define('STR_ACTN_ATTRIBUTENOTE', "Cet objet devra �?ªtre associ�?© avec un attribut pour �?ªtre utilis�?©. Voir le menu Admin..Attributs.");
?>