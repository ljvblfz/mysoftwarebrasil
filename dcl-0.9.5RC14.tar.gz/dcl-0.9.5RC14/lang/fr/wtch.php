<?php
	define('STR_WTCH_TABLETITLE', "Mes Alerteurs - %s");
	define('STR_WTCH_NOWTCHS', "Aucun alerteur ne peut �?ªtre trouv�?© pour l\'affichage! Peut-�?ªtre n\'avez vous pas d\'alerteurs d�?©finis dans le syst�?¨me!");
	define('STR_WTCH_ID', "ID");
	define('STR_WTCH_TYPE', "Type");
	define('STR_WTCH_SUMMARY', "R�?©sum�?©");
	define('STR_WTCH_WHO', "Qui");
	define('STR_WTCH_ACTIONS', "Actions");
	define('STR_WTCH_OPTIONS', "Options");
	define('STR_WTCH_EDIT', "Editer %s Alerteur");
	define('STR_WTCH_ADD', "Ajouter %s Alerteur");
	define('STR_WTCH_YOUHAVENONE', "Vous n\'avez pas d\'alerteurs d�?©finis.");
	define('STR_WTCH_HIGHLIGHTEDNOTE', "** Les champs en surbrillance sont obligatoires!");
	define('STR_WTCH_ALLSEQ', "Toutes les S�?©quences");
	define('STR_WTCH_INVALIDITEM', "Eh? Element Alerteur Invalide.");
	define('STR_WTCH_MYWTCH', "Mes Alerteurs");
	define('STR_WTCH_PRODUCT', "Produits");
	define('STR_WTCH_PROJECT', "Projet");
	define('STR_WTCH_PRODUCTWO', "OT Produit");
	define('STR_WTCH_PRODUCTTICKET', "Ticket Produit");
	define('STR_WTCH_WORKORDER', "Ordre de Travail");
	define('STR_WTCH_TICKET', "Ticket");
	define('STR_WTCH_OPEN', "Ouvert");
	define('STR_WTCH_CLOSED', "Ferm�?©");
	define('STR_WTCH_STATUS', "Statut");
	define('STR_WTCH_ANYTHING', "Tout");
	define('STR_WTCH_ACCTWO', "Account Work Order");
	define('STR_WTCH_ACCTTCK', "Account Ticket");
?>