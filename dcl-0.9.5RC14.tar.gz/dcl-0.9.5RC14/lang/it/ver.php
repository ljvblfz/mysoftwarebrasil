<?php
	define('STR_VER_TITLE', "Informazioni sul Sistema");
	define('STR_VER_DCL', "Versione DCL");
	define('STR_VER_SERVEROS', "Sistema Operativo");
	define('STR_VER_SERVERNAME', "Nome Server");
	define('STR_VER_WEBSERVER', "Nome Server Web");
	define('STR_VER_PHPVER', "Versione PHP");
	define('STR_VER_YOURVER', "Versione");
	define('STR_VER_YOURIP', "Indirizzo IP");
	define('STR_VER_YOURBROWSER', "Browser");
?>