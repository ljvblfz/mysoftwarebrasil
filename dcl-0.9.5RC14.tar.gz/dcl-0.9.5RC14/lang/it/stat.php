<?php
	define('STR_STAT_SELECTONE', "Seleziona un elemento");
	define('STR_STAT_TABLETITLE', "Status- Ordinati per %s");
	define('STR_STAT_NOSTATS', "Statuses could not be found for display!  You may not have any statuses in your system yet!");
	define('STR_STAT_ID', "ID");
	define('STR_STAT_ACTIVEABB', "A");
	define('STR_STAT_ACTIVE', "Attive");
	define('STR_STAT_SHORT', "Ordina");
	define('STR_STAT_NAME', "Nome");
	define('STR_STAT_OPTIONS', "Opzioni");
	define('STR_STAT_EDIT', "Modifica lo Status");
	define('STR_STAT_ADD', "Inserisci uno Status");
	define('STR_STAT_HIGHLIGHTEDNOTE', "** I campi evidenziati sono Obbligatori!");
	define('STR_STAT_TYPE', "Type");
?>