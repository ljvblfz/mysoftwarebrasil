<?php
	define('STR_TC_ACTIONTITLE', "Azione (%s su %s) - %s");
	define('STR_TC_STATUS', "Status");
	define('STR_TC_VERSION', "Versione");
	define('STR_TC_ACTION', "Azione");
	define('STR_TC_HOURS', "Ore");
	define('STR_TC_DESCRIPTION', "Descrizione");
	define('STR_TC_EDIT', "Modifica il Time Card");
	define('STR_TC_JCN', "WO#");
	define('STR_TC_SEQ', "Seq");
	define('STR_TC_DETAILBELOW', "(Dettagli)");
	define('STR_TC_SUMMARY', "Descrizione Breve");
	define('STR_TC_DATE', "Data");
	define('STR_TC_BY', "Da");
	define('STR_TC_ETC', "Rimanenti");
	define('STR_TC_BTNADD', "Nuovo");
	define('STR_TC_BTNMOD', "Modifica");
	define('STR_TC_BTNCLR', "Pulisci");
	define('STR_TC_HIGHLIGHTEDNOTE', "** I Campi evidenziati sono obbligatori!");
	define('STR_TC_MODIFYNOTE', "ATTENZIONE: Se un qualsiasi Time Card appare nella schermata sottostanre, lo status e le ore ETC non possono essere modificate.");
	define('STR_TC_MODIFY', "Modifica");
	define('STR_TC_DELETE', "Elimina");
	define('STR_TC_BATCHUPDATE', "Batch Update");
?>