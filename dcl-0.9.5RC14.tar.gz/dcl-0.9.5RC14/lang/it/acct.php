<?php
	define('STR_ACCT_SELECTONE', "Seleziona un elemento.");
	define('STR_ACCT_DIRBYNAME', "Clienti ordinati per nome");
	define('STR_ACCT_TABLETITLE', "Clienti - Ordinamento per %s Contenente %s");
	define('STR_ACCT_NOTFOUND', "Nessun Cliente trovato per %s Contenente %s");
	define('STR_ACCT_OPTIONS', "Opzioni");
	define('STR_ACCT_ID', "ID");
	define('STR_ACCT_ACTIVEABB', "A");
	define('STR_ACCT_ACTIVE', "Attiva");
	define('STR_ACCT_NAME', "Nome");
	define('STR_ACCT_NOTES', "Note");
	define('STR_ACCT_SHORT', "Breve");
	define('STR_ACCT_CITY', "Citta\'");
	define('STR_ACCT_STATEABB', "Stato");
	define('STR_ACCT_STATE', "Prov");
	define('STR_ACCT_ZIP', "CAP");
	define('STR_ACCT_CONTACT', "Contatto");
	define('STR_ACCT_CONTACTPH', "Contatto Telefonico");
	define('STR_ACCT_FAX', "Fax");
	define('STR_ACCT_EDITACCOUNT', "Modifica Contatto");
	define('STR_ACCT_ADDNEWACCOUNT', "Nuovo Contatto");
	define('STR_ACCT_HIGHLIGHTEDNOTE', "** I Campi evidenziati sono obligatori!");
	define('STR_ACCT_NOOBJECTERR', "Non e\' possibile visualizzare il cliente !");
	define('STR_ACCT_ACCOUNTSEARCH', "Account Search");
	define('STR_ACCT_SEARCHTEXT', "Search Text");
	define('STR_ACCT_WATCHWO', "Watch WO");
	define('STR_ACCT_WATCHTCK', "Watch Ticket");
?>