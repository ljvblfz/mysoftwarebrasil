<?php
	define('STR_PRIO_SELECTONE', "Seleziona un elemento");
	define('STR_PRIO_TABLETITLE', "Priorita\'- Ordinate per %s");
	define('STR_PRIO_NOPRIOS', "Le Priorita\' non possono essere visualizzate! Molto probabilmente non sono presenti Priorita\'!");
	define('STR_PRIO_ID', "ID");
	define('STR_PRIO_ACTIVEABB', "A");
	define('STR_PRIO_ACTIVE', "Attiva");
	define('STR_PRIO_SHORT', "Ordinamento");
	define('STR_PRIO_NAME', "Nome");
	define('STR_PRIO_WEIGHT', "Gravita\'");
	define('STR_PRIO_OPTIONS', "Opzioni");
	define('STR_PRIO_EDIT', "Modifica Priorita");
	define('STR_PRIO_ADD', "Inserisci Priorita");
	define('STR_PRIO_HIGHLIGHTEDNOTE', "** I campi evidenziati sono obbligatori!");
?>