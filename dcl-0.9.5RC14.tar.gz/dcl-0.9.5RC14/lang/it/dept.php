<?php
	define('STR_DEPT_SELECTONE', "Seleziona un elemento");
	define('STR_DEPT_TABLETITLE', "Divisioni - Ordinate per %s");
	define('STR_DEPT_NODEPTS', "Le divisioni non possono essere visualizzate! Molto probabilmente nel database non sono presenti Divisioni!");
	define('STR_DEPT_ID', "ID");
	define('STR_DEPT_ACTIVEABB', "A");
	define('STR_DEPT_ACTIVE', "Attiva");
	define('STR_DEPT_SHORT', "Ordinamento");
	define('STR_DEPT_NAME', "Nome");
	define('STR_DEPT_OPTIONS', "Opzioni");
	define('STR_DEPT_EDIT', "Modifica Divisione");
	define('STR_DEPT_ADD', "Nuova Divisione");
	define('STR_DEPT_HIGHLIGHTEDNOTE', "** I campi evidenziati sono obbligatori!");
?>