<?php
	define('STR_ATTR_OBJECTNOTPASSED', "An object was not passed!");
	define('STR_ATTR_INVALIDTYPE', "An invalid type was passed!");
	define('STR_ATTR_ATTRIBUTESET', "Attribute Set");
	define('STR_ATTR_ATTRIBUTESETS', "Attribute Sets");
	define('STR_ATTR_ACTIONS', "Actions");
	define('STR_ATTR_PRIORITIES', "Priorities");
	define('STR_ATTR_SEVERITIES', "Severities/Types");
	define('STR_ATTR_STATUSES', "Statuses");
	define('STR_ATTR_MAP', "Map");
	define('STR_ATTR_ID', "ID");
	define('STR_ATTR_ACTIVE', "Active");
	define('STR_ATTR_SHORT', "Short");
	define('STR_ATTR_NAME', "Name");
	define('STR_ATTR_ADDATTRIBUTESET', "Add Attribute Set");
	define('STR_ATTR_EDITATTRIBUTESET', "Edit Attribute Set");
	define('STR_ATTR_AVAILABLEVALUES', "Available Values");
	define('STR_ATTR_USEDVALUES', "Used Values");
	define('STR_ATTR_SELECTONE', "Select One");
	define('STR_ATTR_NEW', "New");
	define('STR_ATTR_TYPE', "Type");
	define('STR_ATTR_NOATTRIBUTESETS', "No Attribute Sets Defined!");
	define('STR_ATTR_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
?>