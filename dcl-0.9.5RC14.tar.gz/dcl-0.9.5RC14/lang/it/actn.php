<?php
	define('STR_ACTN_SELECTONE', "Seleziona un elemento");
	define('STR_ACTN_TABLETITLE', "Azioni- Ordinate per %s");
	define('STR_ACTN_NOACTIONS', "Le azioni non possono essere visualizzate! Molto probabilmente l\'archivio non contiene nessuna Azione!");
	define('STR_ACTN_ID', "ID");
	define('STR_ACTN_ACTIVEABB', "A");
	define('STR_ACTN_ACTIVE', "Attiva");
	define('STR_ACTN_SHORT', "Ordinamento");
	define('STR_ACTN_NAME', "Nome");
	define('STR_ACTN_OPTIONS', "Opzioni");
	define('STR_ACTN_EDIT', "Modifica Azione");
	define('STR_ACTN_ADD', "Nuova Azione");
	define('STR_ACTN_HIGHLIGHTEDNOTE', "** I campi evidenziati sono obbligatori!");
	define('STR_ACTN_ATTRIBUTENOTE', "This item will need to be associated with an attribute set to be used.  See Admin..Attributes menu item.");
?>