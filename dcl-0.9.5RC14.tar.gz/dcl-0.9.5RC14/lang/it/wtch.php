<?php
	define('STR_WTCH_TABLETITLE', "Miei Avvisi- %s");
	define('STR_WTCH_NOWTCHS', "Non sono stati trovati avvisi da visualizzare! Molto probabilmente non hai configurato nessun avviso!");
	define('STR_WTCH_ID', "ID");
	define('STR_WTCH_TYPE', "Tipo");
	define('STR_WTCH_SUMMARY', "Sommario");
	define('STR_WTCH_WHO', "Chi");
	define('STR_WTCH_ACTIONS', "Azioni");
	define('STR_WTCH_OPTIONS', "Opzioni");
	define('STR_WTCH_EDIT', "Modifica l\'avviso %s ");
	define('STR_WTCH_ADD', "Inserisci l\'avviso %s");
	define('STR_WTCH_YOUHAVENONE', "Non hai abilitato nessun avviso.");
	define('STR_WTCH_HIGHLIGHTEDNOTE', "** I campi evidenziati sono obbligatori!");
	define('STR_WTCH_ALLSEQ', "Tutte le sequenza");
	define('STR_WTCH_INVALIDITEM', "Eh? Elemento non trovato.");
	define('STR_WTCH_MYWTCH', "Miei Controlli");
	define('STR_WTCH_PRODUCT', "Prodotto");
	define('STR_WTCH_PROJECT', "Progetto");
	define('STR_WTCH_PRODUCTWO', "Product WO");
	define('STR_WTCH_PRODUCTTICKET', "Product Ticket");
	define('STR_WTCH_WORKORDER', "Work Order");
	define('STR_WTCH_TICKET', "Ticket");
	define('STR_WTCH_OPEN', "Open");
	define('STR_WTCH_CLOSED', "Closed");
	define('STR_WTCH_STATUS', "Status");
	define('STR_WTCH_ANYTHING', "Anything");
	define('STR_WTCH_ACCTWO', "Account Work Order");
	define('STR_WTCH_ACCTTCK', "Account Ticket");
?>