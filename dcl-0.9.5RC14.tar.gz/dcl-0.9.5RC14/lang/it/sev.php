<?php
	define('STR_SEV_SELECTONE', "Seleziona un Elemento");
	define('STR_SEV_TABLETITLE', "Problematiche - Ordinate per %s");
	define('STR_SEV_NOSEVS', "Le problematiche non possono essere visualizzate! Molto probabilmente nell\'archivio non sono presenti problematiche!");
	define('STR_SEV_ID', "ID");
	define('STR_SEV_ACTIVEABB', "A");
	define('STR_SEV_ACTIVE', "Attiva");
	define('STR_SEV_SHORT', "Ordinamento");
	define('STR_SEV_NAME', "Nome");
	define('STR_SEV_WEIGHT', "Gravita\'");
	define('STR_SEV_OPTIONS', "Opzioni");
	define('STR_SEV_EDIT', "Modifica Problematica");
	define('STR_SEV_ADD', "Inserisci Problematica");
?>