<?php
	define('STR_VW_SAVESEARCH', "Save Search");
	define('STR_VW_EXPORTRESULTS', "Export Results");
	define('STR_VW_BATCHTIMECARD', "Batch Timecard");
	define('STR_VW_VIEWOBJECTNOTPASSED', "A view object was not passed!");
	define('STR_VW_UNKNOWNTABLE', "Unknown Table %s");
	define('STR_VW_QUERYERR', "Error executing query: %s");
	define('STR_VW_NOMATCHES', "No Matches Found");
	define('STR_VW_OPEN', "Open: %d");
	define('STR_VW_CLOSED', "Closed: %d");
	define('STR_VW_TOTAL', "Total: %d");
	define('STR_VW_ID', "ID");
	define('STR_VW_OWNER', "Owner");
	define('STR_VW_PUBLIC', "Public");
	define('STR_VW_NAME', "Name");
	define('STR_VW_TABLE', "Table");
	define('STR_VW_ADDVIEW', "Add View");
	define('STR_VW_NOVIEWS', "No Public Or Private Views Found!");
	define('STR_VW_TITLE', "Views Ordered By %s");
	define('STR_VW_SETUP', "Setup");
?>