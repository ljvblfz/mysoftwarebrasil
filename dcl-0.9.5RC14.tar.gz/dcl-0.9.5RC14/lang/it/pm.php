<?php
	define('STR_PM_ADDTOPRJ', "Inserisci al Progetto");
	define('STR_PM_CHOOSEPRJ', "Seleziona a quale progetto inserire");
	define('STR_PM_ADDALLSEQ', "Inserisci tutte le sequenze per questo Lavoro WO#");
?>