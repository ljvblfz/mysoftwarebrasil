<?php
	define('STR_SEV_SELECTONE', "Seleccione Uno");
	define('STR_SEV_TABLETITLE', "Severidades - Ordenadas por %s");
	define('STR_SEV_NOSEVS', "No se pudo encontrar las severidades para mostrar!  No debe tenrer severidades en su sistema todavia!");
	define('STR_SEV_ID', "ID");
	define('STR_SEV_ACTIVEABB', "A");
	define('STR_SEV_ACTIVE', "Activo");
	define('STR_SEV_SHORT', "Short");
	define('STR_SEV_NAME', "Nombre");
	define('STR_SEV_WEIGHT', "Weight");
	define('STR_SEV_OPTIONS', "Opciones");
	define('STR_SEV_EDIT', "Editar Severidad");
	define('STR_SEV_ADD', "A�?±adir Severidad");
?>