<?php
	define('STR_VER_TITLE', "Informacion de la Version del Sistema");
	define('STR_VER_DCL', "Version del DCL");
	define('STR_VER_SERVEROS', "Sistema Operativo de Servidor");
	define('STR_VER_SERVERNAME', "Nombre del Servidor");
	define('STR_VER_WEBSERVER', "Pagina del Servidor");
	define('STR_VER_PHPVER', "Version de PHP");
	define('STR_VER_YOURVER', "Your Version Information");
	define('STR_VER_YOURIP', "Su direccion IP");
	define('STR_VER_YOURBROWSER', "Su Navegador");
?>