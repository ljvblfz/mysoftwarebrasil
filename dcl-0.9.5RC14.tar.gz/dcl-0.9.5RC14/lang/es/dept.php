<?php
	define('STR_DEPT_SELECTONE', "Seleccione uno");
	define('STR_DEPT_TABLETITLE', "Departamentos - Ordenados por %s");
	define('STR_DEPT_NODEPTS', "Los departamentos no pudieron ser encontrados!  No debe tener algun departamento en su sistema!");
	define('STR_DEPT_ID', "ID");
	define('STR_DEPT_ACTIVEABB', "A");
	define('STR_DEPT_ACTIVE', "Activo");
	define('STR_DEPT_SHORT', "Diminutivo");
	define('STR_DEPT_NAME', "Nombre");
	define('STR_DEPT_OPTIONS', "Opciones");
	define('STR_DEPT_EDIT', "Editar Departamento");
	define('STR_DEPT_ADD', "A�?±adir Departamento");
	define('STR_DEPT_HIGHLIGHTEDNOTE', "** Los campos sombreados deben ser rellenados!");
?>