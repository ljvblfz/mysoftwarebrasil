<?php
	define('STR_VW_SAVESEARCH', "Salvar busqueda");
	define('STR_VW_EXPORTRESULTS', "Exportar Resultados");
	define('STR_VW_BATCHTIMECARD', "Batch Timecard");
	define('STR_VW_VIEWOBJECTNOTPASSED', "A view object was not passed!");
	define('STR_VW_UNKNOWNTABLE', "Tabla desconocida %s");
	define('STR_VW_QUERYERR', "Error de ejecucion preguntar: %s");
	define('STR_VW_NOMATCHES', "Coincidencias no encontradas");
	define('STR_VW_OPEN', "abierto: %d");
	define('STR_VW_CLOSED', "Cerrado: %d");
	define('STR_VW_TOTAL', "Total: %d");
	define('STR_VW_ID', "ID");
	define('STR_VW_OWNER', "Propietario");
	define('STR_VW_PUBLIC', "Publico");
	define('STR_VW_NAME', "Nombre");
	define('STR_VW_TABLE', "Tabla");
	define('STR_VW_ADDVIEW', "A�?±adir Vista");
	define('STR_VW_NOVIEWS', "No encontrados vistas publicas ni privadas!");
	define('STR_VW_TITLE', "Vistas ordenadas por %s");
	define('STR_VW_SETUP', "Setup");
?>