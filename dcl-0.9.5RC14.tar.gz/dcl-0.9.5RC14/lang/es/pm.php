<?php
	define('STR_PM_ADDTOPRJ', "A�?±adir a Proyectos");
	define('STR_PM_CHOOSEPRJ', "Elegir el Proyecto para a�?±adir a");
	define('STR_PM_ADDALLSEQ', "A�?±adir todas las Sequences para esta WO#");
?>