<?php
	define('STR_ACCT_SELECTONE', "Seleccione Uno");
	define('STR_ACCT_DIRBYNAME', "Directorio de cuenta por nombre");
	define('STR_ACCT_TABLETITLE', "cuenta - ordenadas por %s conteniendo %s");
	define('STR_ACCT_NOTFOUND', "Ninguna cuenta encontrada para %s conteniendo %s");
	define('STR_ACCT_OPTIONS', "Opciones");
	define('STR_ACCT_ID', "ID");
	define('STR_ACCT_ACTIVEABB', "A");
	define('STR_ACCT_ACTIVE', "Activo");
	define('STR_ACCT_NAME', "Nombre");
	define('STR_ACCT_NOTES', "Notas");
	define('STR_ACCT_SHORT', "Abrev.");
	define('STR_ACCT_CITY', "Ciudad");
	define('STR_ACCT_STATEABB', "Calle");
	define('STR_ACCT_STATE', "Estado");
	define('STR_ACCT_ZIP', "Zip");
	define('STR_ACCT_CONTACT', "Usuario");
	define('STR_ACCT_CONTACTPH', "telefono");
	define('STR_ACCT_FAX', "Fax");
	define('STR_ACCT_EDITACCOUNT', "Editar cuenta");
	define('STR_ACCT_ADDNEWACCOUNT', "A�?±adir nuevo cuenta");
	define('STR_ACCT_HIGHLIGHTEDNOTE', "** Los campos sombreados son obligatorios!");
	define('STR_ACCT_NOOBJECTERR', "cuenta object not passed to ShowDetail!");
	define('STR_ACCT_ACCOUNTSEARCH', "Buscar cuenta");
	define('STR_ACCT_SEARCHTEXT', "Buscar texto");
	define('STR_ACCT_WATCHWO', "Watch WO");
	define('STR_ACCT_WATCHTCK', "Watch Ticket");
?>