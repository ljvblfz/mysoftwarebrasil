<?php
	define('STR_ATTR_OBJECTNOTPASSED', "Un objeto que no paso!");
	define('STR_ATTR_INVALIDTYPE', "Un tipo no valido fue permitido!");
	define('STR_ATTR_ATTRIBUTESET', "Conjunto de atributos");
	define('STR_ATTR_ATTRIBUTESETS', "Conjuntos de atributos");
	define('STR_ATTR_ACTIONS', "Acciones");
	define('STR_ATTR_PRIORITIES', "Prioridades");
	define('STR_ATTR_SEVERITIES', "Severidad");
	define('STR_ATTR_STATUSES', "Estados");
	define('STR_ATTR_MAP', "Mapa");
	define('STR_ATTR_ID', "ID");
	define('STR_ATTR_ACTIVE', "Activo");
	define('STR_ATTR_SHORT', "Abrev.");
	define('STR_ATTR_NAME', "Nombre");
	define('STR_ATTR_ADDATTRIBUTESET', "A�?±adir conjunto de atributos");
	define('STR_ATTR_EDITATTRIBUTESET', "Editar conjunto de atributos");
	define('STR_ATTR_AVAILABLEVALUES', "Valores disponibles");
	define('STR_ATTR_USEDVALUES', "Valores usados");
	define('STR_ATTR_SELECTONE', "Seleccione uno");
	define('STR_ATTR_NEW', "Nuevo");
	define('STR_ATTR_TYPE', "Tipo");
	define('STR_ATTR_NOATTRIBUTESETS', "Conjunto de atributos no definidos!");
	define('STR_ATTR_HIGHLIGHTEDNOTE', "**Los campos sombreados son oblgatorios!");
?>