<?php
	define('STR_TC_ACTIONTITLE', "Accion (%s on %s) - %s");
	define('STR_TC_STATUS', "Estado");
	define('STR_TC_VERSION', "Version");
	define('STR_TC_ACTION', "Accion");
	define('STR_TC_HOURS', "Horas");
	define('STR_TC_DESCRIPTION', "Descripcion");
	define('STR_TC_EDIT', "Editing Time Card");
	define('STR_TC_JCN', "WO#");
	define('STR_TC_SEQ', "Seq");
	define('STR_TC_DETAILBELOW', "(Detail Below)");
	define('STR_TC_SUMMARY', "Sumario");
	define('STR_TC_DATE', "Fecha");
	define('STR_TC_BY', "Por");
	define('STR_TC_ETC', "ETC");
	define('STR_TC_BTNADD', "A�?±adir");
	define('STR_TC_BTNMOD', "Modificar");
	define('STR_TC_BTNCLR', "Limpiar");
	define('STR_TC_HIGHLIGHTEDNOTE', "** Los campos sombreados son obligatorios!");
	define('STR_TC_MODIFYNOTE', "NOTE: If any time cards appear below this one, status and ETC hours will not be changed.");
	define('STR_TC_MODIFY', "Modificado");
	define('STR_TC_DELETE', "Borrar");
	define('STR_TC_BATCHUPDATE', "Batch Update");
?>