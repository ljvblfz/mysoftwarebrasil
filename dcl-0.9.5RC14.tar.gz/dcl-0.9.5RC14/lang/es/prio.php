<?php
	define('STR_PRIO_SELECTONE', "Seleccione uno");
	define('STR_PRIO_TABLETITLE', "Prioridades - Ordenados por %s");
	define('STR_PRIO_NOPRIOS', "Las prioridades no fuerosn encontradas para mostrar!  No debe tener prioridades en su sistema actual!");
	define('STR_PRIO_ID', "ID");
	define('STR_PRIO_ACTIVEABB', "A");
	define('STR_PRIO_ACTIVE', "Activo");
	define('STR_PRIO_SHORT', "Short");
	define('STR_PRIO_NAME', "Nombre");
	define('STR_PRIO_WEIGHT', "Weight");
	define('STR_PRIO_OPTIONS', "Opciones");
	define('STR_PRIO_EDIT', "Editar Prioridad");
	define('STR_PRIO_ADD', "A�?±adir Prioridad");
	define('STR_PRIO_HIGHLIGHTEDNOTE', "** Los campos sombreados deben estar rellenados!");
?>