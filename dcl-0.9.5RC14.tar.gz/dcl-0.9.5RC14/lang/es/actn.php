<?php
	define('STR_ACTN_SELECTONE', "Seleccione uno");
	define('STR_ACTN_TABLETITLE', "Acciones - Ordenadas por %s");
	define('STR_ACTN_NOACTIONS', "Las Acciones no pudieron ser encontradas para mostrar.No debes tener ninguna accion en tu sistema todavia");
	define('STR_ACTN_ID', "ID");
	define('STR_ACTN_ACTIVEABB', "A");
	define('STR_ACTN_ACTIVE', "Activo");
	define('STR_ACTN_SHORT', "Abrev.");
	define('STR_ACTN_NAME', "Nombre");
	define('STR_ACTN_OPTIONS', "opciones");
	define('STR_ACTN_EDIT', "Editar accion");
	define('STR_ACTN_ADD', "A�?±adir accion");
	define('STR_ACTN_HIGHLIGHTEDNOTE', "** Los campos sombreados son obligatorios!");
	define('STR_ACTN_ATTRIBUTENOTE', "Este objeto necesitara estar asociado con un conjunto de atributos para ser usado.Ver en propiedades del administrador");
?>