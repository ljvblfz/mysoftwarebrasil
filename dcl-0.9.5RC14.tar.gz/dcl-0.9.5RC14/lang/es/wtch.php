<?php
	define('STR_WTCH_TABLETITLE', "Mis Vistas - %s");
	define('STR_WTCH_NOWTCHS', "No se encontraron Vistas para mostrar!  No debes tener ninguna Vista en tu sistema todavia!");
	define('STR_WTCH_ID', "ID");
	define('STR_WTCH_TYPE', "Tipo");
	define('STR_WTCH_SUMMARY', "Resumen");
	define('STR_WTCH_WHO', "Quien");
	define('STR_WTCH_ACTIONS', "Acciones");
	define('STR_WTCH_OPTIONS', "Opciones");
	define('STR_WTCH_EDIT', "Edite %s Vista");
	define('STR_WTCH_ADD', "A�?±ada %s Vista");
	define('STR_WTCH_YOUHAVENONE', "No tiene ninguna Vista.");
	define('STR_WTCH_HIGHLIGHTEDNOTE', "** Los campos sombreados son obligatorios!");
	define('STR_WTCH_ALLSEQ', "Todas Secuencias");
	define('STR_WTCH_INVALIDITEM', "Eh? Item Vista no valido.");
	define('STR_WTCH_MYWTCH', "Mis Vistas");
	define('STR_WTCH_PRODUCT', "Producto");
	define('STR_WTCH_PROJECT', "Proyecto");
	define('STR_WTCH_PRODUCTWO', "Producto WO");
	define('STR_WTCH_PRODUCTTICKET', "Producto Ticket");
	define('STR_WTCH_WORKORDER', "WO");
	define('STR_WTCH_TICKET', "Ticket");
	define('STR_WTCH_OPEN', "Abierto");
	define('STR_WTCH_CLOSED', "Cerrado");
	define('STR_WTCH_STATUS', "Estado");
	define('STR_WTCH_ANYTHING', "Alguna cosa");
	define('STR_WTCH_ACCTWO', "Account Work Order");
	define('STR_WTCH_ACCTTCK', "Account Ticket");
?>