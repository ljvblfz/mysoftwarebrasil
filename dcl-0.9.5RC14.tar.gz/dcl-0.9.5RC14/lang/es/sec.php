<?php
	define('STR_SEC_SECLOG', "Security Logs");
	define('STR_SEC_SECLOGTITLE', "Security Logs Between %s and %s for %s");
	define('STR_SEC_GENERATEREPORTFOR', "Generar Informe Para");
	define('STR_SEC_DATERANGE', "Rango Fecha");
	define('STR_SEC_BEGIN', "Comenzando");
	define('STR_SEC_ENDING', "Finalizando");
	define('STR_SEC_DATEERR', "No se puede mostrar un informe sin ambas fechas de comienzo y fin.");
	define('STR_SEC_ACTIONON', "Action On");
	define('STR_SEC_ACTIONTXT', "Action");
	define('STR_SEC_ACTIONPARAM', "Details");
	define('STR_SEC_ALLUSERS', "All Users");
	define('STR_SEC_RPTERROR', "An error occured while rendering the report.");
	define('STR_SEC_RPTNODATA', "No data returned.  Please try a broader query.");
?>