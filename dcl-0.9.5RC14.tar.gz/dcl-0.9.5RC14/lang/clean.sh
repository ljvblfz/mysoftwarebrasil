#!/bin/sh
for x in de en es fr it ru sl sv; do
	rm -f $x/*.php
done
