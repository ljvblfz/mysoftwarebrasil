<?php
	define('STR_VER_TITLE', "System Version Information");
	define('STR_VER_DCL', "DCL Version");
	define('STR_VER_SERVEROS', "Server OS-Type");
	define('STR_VER_SERVERNAME', "Server Name");
	define('STR_VER_WEBSERVER', "Web Server");
	define('STR_VER_PHPVER', "PHP Version");
	define('STR_VER_YOURVER', "Your Version Information");
	define('STR_VER_YOURIP', "Your IP Address");
	define('STR_VER_YOURBROWSER', "Your Browser");
?>