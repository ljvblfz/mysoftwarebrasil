<?php
	define('STR_SEV_SELECTONE', "Select One");
	define('STR_SEV_TABLETITLE', "Severities - Ordered By %s");
	define('STR_SEV_NOSEVS', "Severities could not be found for display!  You may not have any severities in your system yet!");
	define('STR_SEV_ID', "ID");
	define('STR_SEV_ACTIVEABB', "A");
	define('STR_SEV_ACTIVE', "Active");
	define('STR_SEV_SHORT', "Short");
	define('STR_SEV_NAME', "Name");
	define('STR_SEV_WEIGHT', "Weight");
	define('STR_SEV_OPTIONS', "Options");
	define('STR_SEV_EDIT', "Edit Severity");
	define('STR_SEV_ADD', "Add Severity");
?>