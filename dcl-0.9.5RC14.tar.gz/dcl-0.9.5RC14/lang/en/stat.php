<?php
	define('STR_STAT_SELECTONE', "Select One");
	define('STR_STAT_TABLETITLE', "Statuses - Ordered By %s");
	define('STR_STAT_NOSTATS', "Statuses could not be found for display!  You may not have any statuses in your system yet!");
	define('STR_STAT_ID', "ID");
	define('STR_STAT_ACTIVEABB', "A");
	define('STR_STAT_ACTIVE', "Active");
	define('STR_STAT_SHORT', "Short");
	define('STR_STAT_NAME', "Name");
	define('STR_STAT_OPTIONS', "Options");
	define('STR_STAT_EDIT', "Edit Status");
	define('STR_STAT_ADD', "Add Status");
	define('STR_STAT_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
	define('STR_STAT_TYPE', "Type");
?>