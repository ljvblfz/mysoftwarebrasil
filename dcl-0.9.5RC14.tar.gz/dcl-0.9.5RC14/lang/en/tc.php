<?php
	define('STR_TC_ACTIONTITLE', "Action (%s on %s) - %s");
	define('STR_TC_STATUS', "Status");
	define('STR_TC_VERSION', "Version");
	define('STR_TC_ACTION', "Action");
	define('STR_TC_HOURS', "Hours");
	define('STR_TC_DESCRIPTION', "Description");
	define('STR_TC_EDIT', "Editing Time Card");
	define('STR_TC_JCN', "WO#");
	define('STR_TC_SEQ', "Seq");
	define('STR_TC_DETAILBELOW', "(Detail Below)");
	define('STR_TC_SUMMARY', "Summary");
	define('STR_TC_DATE', "Date");
	define('STR_TC_BY', "By");
	define('STR_TC_ETC', "ETC");
	define('STR_TC_BTNADD', "Add");
	define('STR_TC_BTNMOD', "Modify");
	define('STR_TC_BTNCLR', "Clear");
	define('STR_TC_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
	define('STR_TC_MODIFYNOTE', "NOTE: If any time cards appear below this one, status and ETC hours will not be changed.");
	define('STR_TC_MODIFY', "Modify");
	define('STR_TC_DELETE', "Delete");
	define('STR_TC_BATCHUPDATE', "Batch Update");
?>