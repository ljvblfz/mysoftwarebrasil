<?php
	define('STR_ACCT_SELECTONE', "Select One.");
	define('STR_ACCT_DIRBYNAME', "Organization Directory By Name");
	define('STR_ACCT_TABLETITLE', "Organizations - Ordered By %s Containing %s");
	define('STR_ACCT_NOTFOUND', "No Organizations Found For %s Containing %s");
	define('STR_ACCT_OPTIONS', "Options");
	define('STR_ACCT_ID', "ID");
	define('STR_ACCT_ACTIVEABB', "A");
	define('STR_ACCT_ACTIVE', "Active");
	define('STR_ACCT_NAME', "Name");
	define('STR_ACCT_NOTES', "Notes");
	define('STR_ACCT_SHORT', "Short");
	define('STR_ACCT_CITY', "City");
	define('STR_ACCT_STATEABB', "St");
	define('STR_ACCT_STATE', "State");
	define('STR_ACCT_ZIP', "Zip");
	define('STR_ACCT_CONTACT', "Contact");
	define('STR_ACCT_CONTACTPH', "Contact Ph");
	define('STR_ACCT_FAX', "Fax");
	define('STR_ACCT_EDITACCOUNT', "Edit Account");
	define('STR_ACCT_ADDNEWACCOUNT', "Add New Account");
	define('STR_ACCT_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
	define('STR_ACCT_NOOBJECTERR', "Organization object not passed to ShowDetail!");
	define('STR_ACCT_ACCOUNTSEARCH', "Organization Search");
	define('STR_ACCT_SEARCHTEXT', "Search Text");
	define('STR_ACCT_WATCHWO', "Watch WO");
	define('STR_ACCT_WATCHTCK', "Watch Ticket");
?>