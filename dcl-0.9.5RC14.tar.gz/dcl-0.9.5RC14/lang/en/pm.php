<?php
	define('STR_PM_ADDTOPRJ', "Add To Project");
	define('STR_PM_CHOOSEPRJ', "Choose the project to add to");
	define('STR_PM_ADDALLSEQ', "Add All Sequences For This WO#");
?>