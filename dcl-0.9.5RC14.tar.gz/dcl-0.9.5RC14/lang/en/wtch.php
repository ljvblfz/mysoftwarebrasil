<?php
	define('STR_WTCH_TABLETITLE', "My Watches - %s");
	define('STR_WTCH_NOWTCHS', "Watches could not be found for display!  You may not have any watches in your system yet!");
	define('STR_WTCH_ID', "ID");
	define('STR_WTCH_TYPE', "Type");
	define('STR_WTCH_SUMMARY', "Summary");
	define('STR_WTCH_WHO', "Who");
	define('STR_WTCH_ACTIONS', "Actions");
	define('STR_WTCH_OPTIONS', "Options");
	define('STR_WTCH_EDIT', "Edit %s Watch");
	define('STR_WTCH_ADD', "Add %s Watch");
	define('STR_WTCH_YOUHAVENONE', "You do not have any watches.");
	define('STR_WTCH_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
	define('STR_WTCH_ALLSEQ', "All Sequences");
	define('STR_WTCH_INVALIDITEM', "Eh? Invalid watch item.");
	define('STR_WTCH_MYWTCH', "My Watches");
	define('STR_WTCH_PRODUCT', "Product");
	define('STR_WTCH_PROJECT', "Project");
	define('STR_WTCH_PRODUCTWO', "Product WO");
	define('STR_WTCH_PRODUCTTICKET', "Product Ticket");
	define('STR_WTCH_WORKORDER', "Work Order");
	define('STR_WTCH_TICKET', "Ticket");
	define('STR_WTCH_OPEN', "Open");
	define('STR_WTCH_CLOSED', "Closed");
	define('STR_WTCH_STATUS', "Status");
	define('STR_WTCH_ANYTHING', "Anything");
	define('STR_WTCH_ACCTWO', "Account Work Order");
	define('STR_WTCH_ACCTTCK', "Account Ticket");
?>