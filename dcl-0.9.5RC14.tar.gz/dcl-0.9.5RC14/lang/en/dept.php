<?php
	define('STR_DEPT_SELECTONE', "Select One");
	define('STR_DEPT_TABLETITLE', "Departments - Ordered By %s");
	define('STR_DEPT_NODEPTS', "Departments could not be found for display!  You may not have any departments in your system yet!");
	define('STR_DEPT_ID', "ID");
	define('STR_DEPT_ACTIVEABB', "A");
	define('STR_DEPT_ACTIVE', "Active");
	define('STR_DEPT_SHORT', "Short");
	define('STR_DEPT_NAME', "Name");
	define('STR_DEPT_OPTIONS', "Options");
	define('STR_DEPT_EDIT', "Edit Department");
	define('STR_DEPT_ADD', "Add Department");
	define('STR_DEPT_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
?>