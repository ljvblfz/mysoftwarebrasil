<?php
	define('STR_PRIO_SELECTONE', "Select One");
	define('STR_PRIO_TABLETITLE', "Priorities - Ordered By %s");
	define('STR_PRIO_NOPRIOS', "Priorities could not be found for display!  You may not have any priorities in your system yet!");
	define('STR_PRIO_ID', "ID");
	define('STR_PRIO_ACTIVEABB', "A");
	define('STR_PRIO_ACTIVE', "Active");
	define('STR_PRIO_SHORT', "Short");
	define('STR_PRIO_NAME', "Name");
	define('STR_PRIO_WEIGHT', "Weight");
	define('STR_PRIO_OPTIONS', "Options");
	define('STR_PRIO_EDIT', "Edit Priority");
	define('STR_PRIO_ADD', "Add Priority");
	define('STR_PRIO_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
?>