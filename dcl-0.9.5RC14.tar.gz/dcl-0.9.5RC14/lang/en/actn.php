<?php
	define('STR_ACTN_SELECTONE', "Select One");
	define('STR_ACTN_TABLETITLE', "Actions - Ordered By %s");
	define('STR_ACTN_NOACTIONS', "Actions could not be found for display!  You may not have any actions in your system yet!");
	define('STR_ACTN_ID', "ID");
	define('STR_ACTN_ACTIVEABB', "A");
	define('STR_ACTN_ACTIVE', "Active");
	define('STR_ACTN_SHORT', "Short");
	define('STR_ACTN_NAME', "Name");
	define('STR_ACTN_OPTIONS', "Options");
	define('STR_ACTN_EDIT', "Edit Action");
	define('STR_ACTN_ADD', "Add Action");
	define('STR_ACTN_HIGHLIGHTEDNOTE', "** Highlighted fields are required!");
	define('STR_ACTN_ATTRIBUTENOTE', "This item will need to be associated with an attribute set to be used.  See Admin..Attributes menu item.");
?>