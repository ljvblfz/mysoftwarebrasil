<?php
	define('STR_VW_SAVESEARCH', "Spara s�?¶kning");
	define('STR_VW_EXPORTRESULTS', "Exportera resultat");
	define('STR_VW_BATCHTIMECARD', "Automatisera tidrapport");
	define('STR_VW_VIEWOBJECTNOTPASSED', "Ett vyobjekt skickades inte!");
	define('STR_VW_UNKNOWNTABLE', "Ok�?¤nd tabell %s");
	define('STR_VW_QUERYERR', "Fel n�?¤r fr�?¥gan utf�?¶rdes: %s");
	define('STR_VW_NOMATCHES', "Inget matchar kriteriet");
	define('STR_VW_OPEN', "�?�??ppen: %d");
	define('STR_VW_CLOSED', "St�?¤ngd: %d");
	define('STR_VW_TOTAL', "Totalt: %d");
	define('STR_VW_ID', "ID");
	define('STR_VW_OWNER', "�?�??gare");
	define('STR_VW_PUBLIC', "Publikt");
	define('STR_VW_NAME', "Namn");
	define('STR_VW_TABLE', "Tabell");
	define('STR_VW_ADDVIEW', "L�?¤gg till vy");
	define('STR_VW_NOVIEWS', "Inga privata eller publika vyer hittades!");
	define('STR_VW_TITLE', "Vyer ordnade efter %s");
	define('STR_VW_SETUP', "Setup");
?>