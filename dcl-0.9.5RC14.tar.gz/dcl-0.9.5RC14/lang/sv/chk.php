<?php
	define('STR_CHK_INITIATE', "Initiate");
	define('STR_CHK_TEMPLATE', "Template");
	define('STR_CHK_TEMPLATES', "Templates");
	define('STR_CHK_NEWTEMPLATE', "New Template");
	define('STR_CHK_CHECKLISTTEMPLATES', "Checklist Templates");
	define('STR_CHK_CHECKLISTTEMPLATE', "Checklist Template");
	define('STR_CHK_CHECKLISTNAME', "Checklist Name");
	define('STR_CHK_INITIATEDCHECKLISTS', "Initiated Checklists");
	define('STR_CHK_INITIATECHECKLIST', "Initiate Checklist");
	define('STR_CHK_SUMMARY', "Summary");
	define('STR_CHK_STATUS', "Status");
	define('STR_CHK_ERRLOADINGTPLID', "Error loading template ID #%d");
	define('STR_CHK_TEMPLATEISINACTIVE', "Template is inactive and cannot be initiated.");
	define('STR_CHK_COULDNOTCOPYTPL', "Could not copy template to new checklist.  Operation aborted.");
	define('STR_CHK_ERRORDATABASEENTRY', "Error creating database entry for checklist.");
	define('STR_CHK_STATE', "State");
?>