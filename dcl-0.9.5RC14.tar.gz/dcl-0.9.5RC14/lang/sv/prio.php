<?php
	define('STR_PRIO_SELECTONE', "V�?¤lj en");
	define('STR_PRIO_TABLETITLE', "Prioritet - ordnat efter %s");
	define('STR_PRIO_NOPRIOS', "Inga prioriteter kundes hittas!");
	define('STR_PRIO_ID', "ID");
	define('STR_PRIO_ACTIVEABB', "A");
	define('STR_PRIO_ACTIVE', "Aktiv");
	define('STR_PRIO_SHORT', "Kortnamn");
	define('STR_PRIO_NAME', "Namn");
	define('STR_PRIO_WEIGHT', "Vikt");
	define('STR_PRIO_OPTIONS', "Inst�?¤llningar");
	define('STR_PRIO_EDIT', "�?�??ndra prioritet");
	define('STR_PRIO_ADD', "L�?¤gg till prioritet");
	define('STR_PRIO_HIGHLIGHTEDNOTE', "** Obligatoriskt f�?¤lt.");
?>