<?php
	define('STR_ACTN_SELECTONE', "V�?¤lj en");
	define('STR_ACTN_TABLETITLE', "Aktiviteter - ordnade efter %s");
	define('STR_ACTN_NOACTIONS', "Inga aktiviteter hittades!");
	define('STR_ACTN_ID', "ID");
	define('STR_ACTN_ACTIVEABB', "A");
	define('STR_ACTN_ACTIVE', "Aktiv");
	define('STR_ACTN_SHORT', "Kortnamn");
	define('STR_ACTN_NAME', "Namn");
	define('STR_ACTN_OPTIONS', "Inst�?¤llningar");
	define('STR_ACTN_EDIT', "�?�??ndra aktivitet");
	define('STR_ACTN_ADD', "L�?¤gg till aktivitet");
	define('STR_ACTN_HIGHLIGHTEDNOTE', "** Obligatoriskt f�?¤lt.");
	define('STR_ACTN_ATTRIBUTENOTE', "Detta f�?¤lt m�?¥ste vara associerat med en attributgrupp f�?¶r att anv�?¤ndas. Se menyn Administration.Attributgrupper.");
?>