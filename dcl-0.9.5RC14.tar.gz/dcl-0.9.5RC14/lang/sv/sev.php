<?php
	define('STR_SEV_SELECTONE', "V�?¤lj en");
	define('STR_SEV_TABLETITLE', "Kategorier - ordnade efter %s");
	define('STR_SEV_NOSEVS', "Inga kategorier kunde hittas! M�?¶ljligen finns inga konfigurerade �?¤nnu - kontakta systemadministrat�?¶ren");
	define('STR_SEV_ID', "ID");
	define('STR_SEV_ACTIVEABB', "A");
	define('STR_SEV_ACTIVE', "Aktiv");
	define('STR_SEV_SHORT', "Kortnamn");
	define('STR_SEV_NAME', "Namn");
	define('STR_SEV_WEIGHT', "Vikt");
	define('STR_SEV_OPTIONS', "Inst�?¤llningar");
	define('STR_SEV_EDIT', "�?�??ndra kategori");
	define('STR_SEV_ADD', "L�?¤gg till kategori");
?>