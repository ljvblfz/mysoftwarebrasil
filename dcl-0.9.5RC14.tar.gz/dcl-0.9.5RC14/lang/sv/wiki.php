<?php
	define('DCL_WIKI_PROJECTWIKI', "This Page is a Part of Project Wiki: [%d] %s");
	define('DCL_WIKI_PRODUCTWIKI', "This Page is a Part of Product Wiki: %s");
	define('DCL_WIKI_ACCOUNTWIKI', "This Page is a Part of Account Wiki: %s");
	define('DCL_WIKI_WOWIKI', "This Page is a Part of Work Order Wiki: [%d-%d] %s");
	define('DCL_WIKI_TICKETWIKI', "This Page is a Part of Ticket Wiki: [%d] %s");
	define('DCL_WIKI_EDITTHISPAGE', "Edit This Page");
	define('DCL_WIKI_RETURNTOFRONTPAGE', "Return To FrontPage");
	define('DCL_WIKI_VIEWRECENTCHANGES', "View RecentChanges");
	define('DCL_WIKI_THISPAGECANNOTBEEDITED', "This Page Cannot Be Edited");
	define('DCL_WIKI_EDITINGFORMAT', "Editing Page %s");
	define('DCL_WIKI_NEWPAGEFORMAT', "Type your description for %s here.");
	define('DCL_WIKI_RECENTCHANGES', "Recent Changes");
	define('DCL_WIKI_TOTALPAGESFORMAT', "Total Pages: %d");
	define('DCL_WIKI_PAGE', "Page");
	define('DCL_WIKI_LASTMODIFIED', "Last Modified");
	define('DCL_WIKI_LASTMODIFIEDBY', "By");
?>