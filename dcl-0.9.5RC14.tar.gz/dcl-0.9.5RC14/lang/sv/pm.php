<?php
	define('STR_PM_ADDTOPRJ', "L�?¤gg till projekt");
	define('STR_PM_CHOOSEPRJ', "V�?¤lj projekt");
	define('STR_PM_ADDALLSEQ', "Alla delordrar till denna arbetsorder");
?>