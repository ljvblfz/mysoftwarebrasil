<?php
	define('STR_DEPT_SELECTONE', "V�?¤lj en");
	define('STR_DEPT_TABLETITLE', "Avdelningar - ordnade efter %s");
	define('STR_DEPT_NODEPTS', "Ingen avdelning kunde hittas!  M�?¶jligen finns inga avdelningar konfigurerade - kontakta systemadministrat�?¶ren.");
	define('STR_DEPT_ID', "ID");
	define('STR_DEPT_ACTIVEABB', "A");
	define('STR_DEPT_ACTIVE', "Aktiv");
	define('STR_DEPT_SHORT', "Kortnamn");
	define('STR_DEPT_NAME', "Namn");
	define('STR_DEPT_OPTIONS', "Inst�?¤llningar");
	define('STR_DEPT_EDIT', "�?�??ndra avdelning");
	define('STR_DEPT_ADD', "L�?¤gg till avdelning");
	define('STR_DEPT_HIGHLIGHTEDNOTE', "** Obligatoriskt f�?¤lt.");
?>