<?php
	define('STR_TC_ACTIONTITLE', "Aktivitet (%s on %s) - %s");
	define('STR_TC_STATUS', "Status");
	define('STR_TC_VERSION', "Version");
	define('STR_TC_ACTION', "Aktivitet");
	define('STR_TC_HOURS', "Timmar");
	define('STR_TC_DESCRIPTION', "Beskrivning");
	define('STR_TC_EDIT', "�?�??ndra aktivitetsrapport");
	define('STR_TC_JCN', "Ordernr#");
	define('STR_TC_SEQ', "Delorder");
	define('STR_TC_DETAILBELOW', "(Detaljer nedan)");
	define('STR_TC_SUMMARY', "Sammanfattning");
	define('STR_TC_DATE', "Datum");
	define('STR_TC_BY', "Av");
	define('STR_TC_ETC', "kvar");
	define('STR_TC_BTNADD', "L�?¤gg till");
	define('STR_TC_BTNMOD', "�?�??ndra");
	define('STR_TC_BTNCLR', "Rensa");
	define('STR_TC_HIGHLIGHTEDNOTE', "** Obligatoriskt f�?¤lt.");
	define('STR_TC_MODIFYNOTE', "NOTERA: Om n�?¥gon tidrapport visar sig efter denna som kommer status och tid kvar inte att �?¤ndras.");
	define('STR_TC_MODIFY', "�?�??ndra");
	define('STR_TC_DELETE', "Ta bort");
	define('STR_TC_BATCHUPDATE', "Automatiserad uppdatering");
?>