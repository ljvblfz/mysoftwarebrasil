<?php
	define('STR_ACCT_SELECTONE', "V�?¤lj en");
	define('STR_ACCT_DIRBYNAME', "Konton efter namn");
	define('STR_ACCT_TABLETITLE', "Konton - sorterade efter %s inneh�?¥llande %s");
	define('STR_ACCT_NOTFOUND', "Inga konton hittades f�?¶r %s inneh�?¥llande %s");
	define('STR_ACCT_OPTIONS', "Inst�?¤llningar");
	define('STR_ACCT_ID', "ID");
	define('STR_ACCT_ACTIVEABB', "A");
	define('STR_ACCT_ACTIVE', "Aktiv");
	define('STR_ACCT_NAME', "Namn");
	define('STR_ACCT_NOTES', "Noteringar");
	define('STR_ACCT_SHORT', "Kortnamn");
	define('STR_ACCT_CITY', "Stad");
	define('STR_ACCT_STATEABB', "St");
	define('STR_ACCT_STATE', "Stat");
	define('STR_ACCT_ZIP', "PostNr/Zip");
	define('STR_ACCT_CONTACT', "Kontakt");
	define('STR_ACCT_CONTACTPH', "Kontakttelefon");
	define('STR_ACCT_FAX', "Fax");
	define('STR_ACCT_EDITACCOUNT', "�?�??ndra konto");
	define('STR_ACCT_ADDNEWACCOUNT', "L�?¤gg till konto");
	define('STR_ACCT_HIGHLIGHTEDNOTE', "** Obligatoriskt f�?¤lt.");
	define('STR_ACCT_NOOBJECTERR', "Kontot kunde inte aktiveras!");
	define('STR_ACCT_ACCOUNTSEARCH', "S�?¶k konto");
	define('STR_ACCT_SEARCHTEXT', "Texts�?¶kning");
	define('STR_ACCT_WATCHWO', "Watch WO");
	define('STR_ACCT_WATCHTCK', "Watch Ticket");
?>