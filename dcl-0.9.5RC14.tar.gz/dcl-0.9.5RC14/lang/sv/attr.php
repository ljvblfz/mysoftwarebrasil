<?php
	define('STR_ATTR_OBJECTNOTPASSED', "Ett objekt skickades inte!");
	define('STR_ATTR_INVALIDTYPE', "En felkaktig typ skickades!");
	define('STR_ATTR_ATTRIBUTESET', "Attributgrupp");
	define('STR_ATTR_ATTRIBUTESETS', "Attributgrupper");
	define('STR_ATTR_ACTIONS', "Aktiviteter");
	define('STR_ATTR_PRIORITIES', "Prioriteter");
	define('STR_ATTR_SEVERITIES', "Kategorier");
	define('STR_ATTR_STATUSES', "Status");
	define('STR_ATTR_MAP', "Map");
	define('STR_ATTR_ID', "ID");
	define('STR_ATTR_ACTIVE', "Aktiv");
	define('STR_ATTR_SHORT', "Kortnamn");
	define('STR_ATTR_NAME', "Namn");
	define('STR_ATTR_ADDATTRIBUTESET', "L�?¤gg till attributgrupp");
	define('STR_ATTR_EDITATTRIBUTESET', "�?�??ndra attributgrupp");
	define('STR_ATTR_AVAILABLEVALUES', "Tillg�?¤ngliga v�?¤rden");
	define('STR_ATTR_USEDVALUES', "Anv�?¤nda v�?¤rden");
	define('STR_ATTR_SELECTONE', "V�?¤lj en");
	define('STR_ATTR_NEW', "Ny");
	define('STR_ATTR_TYPE', "Typ");
	define('STR_ATTR_NOATTRIBUTESETS', "Inga attributgrupper definierade!");
	define('STR_ATTR_HIGHLIGHTEDNOTE', "** Obligatoriskt f�?¤lt.");
?>