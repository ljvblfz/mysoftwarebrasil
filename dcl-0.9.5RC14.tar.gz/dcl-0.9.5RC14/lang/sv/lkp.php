<?php
	define('STR_LKP_ADDTITLE', "Add Lookup");
	define('STR_LKP_EDITTITLE', "Edit Lookup");
	define('STR_LKP_TABLETITLE', "Lookups");
	define('STR_LKP_NOLOOKUPS', "No lookups found!");
	define('STR_LKP_ID', "ID");
	define('STR_LKP_ACTIVEABB', "A");
	define('STR_LKP_ACTIVE', "Active");
	define('STR_LKP_NAME', "Name");
	define('STR_LKP_OPTIONS', "Options");
	define('STR_LKP_NOITEMS', "No items found for this lookup!");
	define('STR_LKP_NOTFOUND', "Lookup ID %d does not exist!");
?>