<?php
	define('STR_WTCH_TABLETITLE', "Bevakningar - %s");
	define('STR_WTCH_NOWTCHS', "Inga bevakningar kunde hittas!");
	define('STR_WTCH_ID', "ID");
	define('STR_WTCH_TYPE', "Typ");
	define('STR_WTCH_SUMMARY', "Sammanfattning");
	define('STR_WTCH_WHO', "Vem");
	define('STR_WTCH_ACTIONS', "Aktiviteter");
	define('STR_WTCH_OPTIONS', "Inst�?¤llningar");
	define('STR_WTCH_EDIT', "�?�??ndra %s bevakning");
	define('STR_WTCH_ADD', "L�?¤gg till %s bevakning");
	define('STR_WTCH_YOUHAVENONE', "Du bevakar inte n�?¥got.");
	define('STR_WTCH_HIGHLIGHTEDNOTE', "** Obligatoriskt f�?¤lt.");
	define('STR_WTCH_ALLSEQ', "Alla delordrar");
	define('STR_WTCH_INVALIDITEM', "Ehh? Felaktig bevakning.");
	define('STR_WTCH_MYWTCH', "Bevakningar");
	define('STR_WTCH_PRODUCT', "Produkt");
	define('STR_WTCH_PROJECT', "Projekt");
	define('STR_WTCH_PRODUCTWO', "Product WO");
	define('STR_WTCH_PRODUCTTICKET', "Produktbest�?¤llning");
	define('STR_WTCH_WORKORDER', "Arbetsorder");
	define('STR_WTCH_TICKET', "Beg�?¤ran");
	define('STR_WTCH_OPEN', "�?�??ppen");
	define('STR_WTCH_CLOSED', "St�?¤ngd");
	define('STR_WTCH_STATUS', "Status");
	define('STR_WTCH_ANYTHING', "N�?¥gonting");
	define('STR_WTCH_ACCTWO', "Account Work Order");
	define('STR_WTCH_ACCTTCK', "Account Ticket");
?>