<?php
	define('STR_VER_TITLE', "Systemets versionsinformation");
	define('STR_VER_DCL', "DCL-version");
	define('STR_VER_SERVEROS', "Server OS");
	define('STR_VER_SERVERNAME', "Servernamn");
	define('STR_VER_WEBSERVER', "Webbserver");
	define('STR_VER_PHPVER', "PHP-version");
	define('STR_VER_YOURVER', "Din versionsinformation");
	define('STR_VER_YOURIP', "Din IP-adress");
	define('STR_VER_YOURBROWSER', "Din webbl�?¤sare");
?>