﻿Imports Castle.ActiveRecord

<ActiveRecord("contatos")> _
Public Class Contato
    Inherits ActiveRecordBase(Of Contato)

    Private m_id As Integer
    Private m_nome As String
    Private m_email As String

    <PrimaryKey("Id")> _
    Public Property Id() As Integer
        Get
            Return (m_id)
        End Get
        Set(ByVal value As Integer)
            m_id = value
        End Set
    End Property
    <[Property]("Nome")> _
    Public Property Nome() As String
        Get
            Return (m_nome)
        End Get
        Set(ByVal value As String)
            m_nome = value
        End Set
    End Property
    <[Property]("Email")> _
    Public Property Email() As String
        Get
            Return (m_email)
        End Get
        Set(ByVal value As String)
            m_email = value
        End Set
    End Property

End Class
