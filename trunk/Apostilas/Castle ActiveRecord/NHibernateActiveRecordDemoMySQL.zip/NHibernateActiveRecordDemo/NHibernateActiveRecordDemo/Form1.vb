﻿Public Class Form1

    Private Sub btnListar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnListar.Click
        Try
            gdvContato.DataSource = Contato.FindAll()
        Catch ex As Exception
            MsgBox(" ERRO : " & ex.Message)
        End Try
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        App.Main()
    End Sub
    Private Sub btnNovo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNovo.Click
        My.Forms.Novo.ShowDialog()
    End Sub
    Private Sub btnExcluir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExcluir.Click

        If (MsgBox("Deseja excluir o contato : " & gdvContato.CurrentRow.Cells(1).Value.ToString(), MsgBoxStyle.YesNo) = MsgBoxResult.Yes) Then
            Dim codigo As Integer = Convert.ToInt32(gdvContato.CurrentRow.Cells(0).Value.ToString())
            Dim contato As Contato = contato.Find(Convert.ToInt32(codigo))

            Try
                contato.Delete()
                MsgBox("Contato excluído com sucesso.")
            Catch ex As Exception
                MsgBox("Erro " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnAlterar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAlterar.Click
        My.Forms.Alterar.ShowDialog()
    End Sub

    Private Sub btnSair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSair.Click
        If (MsgBox("Deseja encerrar a aplicação ?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes) Then
            Application.Exit()
        End If
    End Sub
End Class
