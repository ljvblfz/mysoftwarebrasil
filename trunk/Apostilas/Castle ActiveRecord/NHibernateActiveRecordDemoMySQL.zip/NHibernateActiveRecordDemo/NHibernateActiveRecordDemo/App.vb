﻿Imports Castle.ActiveRecord
Imports Castle.ActiveRecord.Framework
Imports Castle.ActiveRecord.Framework.Config
Public Class App

    Public Shared Sub Main()
        ' Dim source As IConfigurationSource = ActiveRecordSectionHandler.Instance
        'ActiveRecordStarter.Initialize(source, GetType(Contato))
        Dim source As XmlConfigurationSource = New XmlConfigurationSource("AppConfig.xml")
        'ActiveRecordStarter.Initialize(source, Type.GetType(Blog), Type.GetType(Post), Type.GetType(User))
        ActiveRecordStarter.Initialize(source, GetType(Contato))

    End Sub

End Class
