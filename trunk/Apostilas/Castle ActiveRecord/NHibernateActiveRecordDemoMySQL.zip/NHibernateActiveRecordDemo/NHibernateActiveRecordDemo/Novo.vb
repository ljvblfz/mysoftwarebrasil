﻿Public Class Novo

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Close()
    End Sub

    Private Sub btnSalvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalvar.Click

        If txtNome.Text <> String.Empty And txtEmail.Text <> String.Empty Then

            Dim contato As New Contato

            contato.Nome = txtNome.Text
            contato.Email = txtEmail.Text
            Try
                contato.Create()
                txtNome.Text = ""
                txtEmail.Text = ""
                MsgBox("Contato criado com sucesso.")
            Catch ex As Exception
                MsgBox("Erro " & ex.Message)
            End Try

        End If
    End Sub
End Class