﻿Public Class Alterar

    Private Sub Alterar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        txtCodigo.Text = Form1.gdvContato.CurrentRow.Cells(0).Value.ToString()
        txtNome.Text = Form1.gdvContato.CurrentRow.Cells(1).Value.ToString()
        txtEmail.Text = Form1.gdvContato.CurrentRow.Cells(2).Value.ToString()
    End Sub

    Private Sub btnSalvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalvar.Click
        Dim codigo As Integer = Convert.ToInt32(txtCodigo.Text)
        Dim contato As Contato = contato.Find(Convert.ToInt32(codigo))

        contato.Nome = txtNome.Text
        contato.Email = txtEmail.Text
        Try
            contato.Update()
            MsgBox("Contato atualizado com sucesso.")
        Catch ex As Exception
            MsgBox("Erro " & ex.Message)
        End Try
    End Sub

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Close()
    End Sub
End Class