﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Simulado_70_515.Questoes._9
{
    public partial class TestPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string s = testControl.CityName;
            //string s = testControl.Attributes["CityName"]; 
        }
    }
}