﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;

namespace Simulado_70_515.Questoes._7
{
    //[Bindable()]
    //[DataObject()]
    [Serializable()]
    //[DataContract()]
    public class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    } 
}