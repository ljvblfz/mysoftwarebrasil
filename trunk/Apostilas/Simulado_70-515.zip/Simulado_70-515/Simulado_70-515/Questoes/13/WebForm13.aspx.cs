﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Simulado_70_515.Questoes._13
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.hdr1.InnerHtml = "Text";

            //(hdr1.Parent as HtmlGenericControl).InnerText = "Text";

            // TAMBEM ESTA CORRETO
            //HtmlGenericControl h1 = this.FindControl("hdr1") as HtmlGenericControl;
            //h1.InnerText = "Text";

            //HtmlGenericControl h1 = Parent.FindControl("hdr1") as HtmlGenericControl;
            //h1.InnerText = "Text"; 


        }
    }
}