﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Simulado_70_515.Questoes._12
{
    public partial class WebForm12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //protected void MyDropDown_PreRender(object sender, EventArgs e)
        //{
        //    DropDownList ddl = sender as DropDownList;
        //    Label lbl = new Label();
        //    lbl.Text = "Option";
        //    lbl.ID = "Option";
        //    ddl.Controls.Add(lbl);
        //}

        protected void MyDropDown_PreRender(object sender, EventArgs e)
        {
            DropDownList ddl = sender as DropDownList;
            ddl.Items.Add("Option");
        }

        //protected void Page_LoadComplete(object sender, EventArgs e)
        //{
        //    DropDownList ddl = Page.FindControl("MyDropDown") as DropDownList; Label lbl = new Label();
        //    lbl.Text = "Option";
        //    lbl.ID = "Option";
        //    ddl.Controls.Add(lbl);
        //}

        //protected void Page_LoadComplete(object sender, EventArgs e)
        //{
        //    DropDownList ddl = Page.FindControl("MyDropDown") as DropDownList; ddl.Items.Add("Option");
        //} 



    }
}