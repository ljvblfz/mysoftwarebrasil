﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Simulado_70_515.Questoes._10
{
    public partial class TestUserControl : System.Web.UI.UserControl
    {
        //public event Simulado_70_515.Questoes._10.TestPage.MyEventHandler MyEvent;
        public Simulado_70_515.Questoes._10.TestPage.MyEventHandler MyEvent; 

        public string CityName
        {
            get { return "New York"; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}