﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Simulado_70_515.Questoes
{
    public partial class TestPage : System.Web.UI.Page
    {
        //A
        protected void Page_Load(object sender, EventArgs e)
        {
            Control userControl = Page.LoadControl("TestUserControl.ascx");
            Page.Form.Controls.Add(userControl);
        }

        //// B
        //protected void Page_Load(object sender, EventArgs e)
        //{
        //    Control userControl = Page.FindControl("TestUserControl.ascx");
        //    Page.Form.Controls.Load(userControl);
        //}

        //// C
        //protected void Page_PreInit(object sender, EventArgs e)
        //{
        //    Control userControl = Page.LoadControl("TestUserControl.ascx");
        //    Page.Form.Controls.Add(userControl);
        //}

        //// D
        //protected void Page_PreInit(object sender, EventArgs e)
        //{
        //    Control userControl = Page.FindControl("TestUserControl.ascx"); 
        //    Page.Form.Controls.Load(userControl);
        //} 
    }
}