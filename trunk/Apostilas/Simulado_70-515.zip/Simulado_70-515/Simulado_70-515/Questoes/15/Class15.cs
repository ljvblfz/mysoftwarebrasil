﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace Simulado_70_515.Questoes._15
{
    public class Class15
    {
        public Class15()
        {
            //bool isMember = Roles.GetUsersInRole("Administrators").Any(); 
            //bool isMember = Membership.ValidateUser(HttpContext.Current.User.Identity.Name, "Administrators"); 
            //bool isMember = Roles.GetRolesForUser("Administrators").Any(); 
            //bool isMember = User.IsInRole("Administrators"); 
        }
    }
}